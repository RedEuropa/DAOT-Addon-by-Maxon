package com.maxonaddon.mixin;

import com.maxonaddon.HostileQteHandler;
import com.maxonaddon.RoyalTitanInteractHandler;
import daot.ShifterTitan;
import daot.BladeItem;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Mixin(LivingEntity.class)
public abstract class PureTitanEatMixin {

    private static final Map<UUID, Long> grabStartTicks = new ConcurrentHashMap<>();

    @Inject(method = "tick", at = @At("HEAD"))
    private void interceptEatingLogic(CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;

        if (self.level().isClientSide()) return;

        if (self instanceof ShifterTitan) return;

        String name = self.getClass().getName();
        if (name.startsWith("daot.") && (name.contains("Titan") || name.contains("ConnieFather")) && !name.contains("Grab") && !name.contains("Eye") && !name.contains("Nape")) {

            if (RoyalTitanInteractHandler.sacrificingTitans.containsKey(self.getUUID())) {
                grabStartTicks.remove(self.getUUID());
                return;
            }

            try {
                Method getEatingTargetMethod = self.getClass().getMethod("getEatingTarget");
                Object targetObj = getEatingTargetMethod.invoke(self);

                if (targetObj instanceof ServerPlayer victim) {
                    UUID victimUuid = victim.getUUID();

                    if (HostileQteHandler.hasGrabImmunity(victim)) {
                        Method cancelEatingMethod = self.getClass().getMethod("cancelEating");
                        cancelEatingMethod.invoke(self);
                        grabStartTicks.remove(self.getUUID());
                        return;
                    }

                    long currentTick = self.level().getGameTime();
                    grabStartTicks.putIfAbsent(victimUuid, currentTick);

                    // Ждем 1 секунду (20 тиков) перед запуском QTE
                    long grabStart = grabStartTicks.get(victimUuid);
                    if (currentTick - grabStart < 20L) {
                        return;
                    }

                    // === ПРОВЕРКА НАЛИЧИЯ ЦЕЛЫХ МЕЧЕЙ В РУКАХ ===
                    ItemStack mainHand = victim.getMainHandItem();
                    ItemStack offHand = victim.getOffhandItem();
                    boolean hasValidBlades = false;

                    if (mainHand.getItem() instanceof BladeItem && BladeItem.getBladeState(mainHand) != BladeItem.BladeState.EMPTY) {
                        hasValidBlades = true;
                    } else if (offHand.getItem() instanceof BladeItem && BladeItem.getBladeState(offHand) != BladeItem.BladeState.EMPTY) {
                        hasValidBlades = true;
                    }

                    // Если мечей нет или они пустые/ломаные — QTE не стартует, титан спокойно ест
                    if (!hasValidBlades) {
                        return;
                    }

                    boolean isQteAlreadyActive = HostileQteHandler.activeEscapes.containsKey(victimUuid);

                    if (!isQteAlreadyActive) {
                        HostileQteHandler.startEscapeQte(victim, (Monster) self);
                        isQteAlreadyActive = HostileQteHandler.activeEscapes.containsKey(victimUuid);
                    }

                    if (isQteAlreadyActive) {
                        Method isEatingMethod = self.getClass().getMethod("isEating");
                        if ((boolean) isEatingMethod.invoke(self)) {
                            Field eatTicksField = self.getClass().getDeclaredField("eatTicks");
                            eatTicksField.setAccessible(true);
                            int currentEatTicks = eatTicksField.getInt(self);

                            if (self.tickCount % 2 == 0) {
                                eatTicksField.setInt(self, currentEatTicks + 1);
                            }
                        }
                    }
                } else {
                    grabStartTicks.remove(self.getUUID());
                }
            } catch (Exception ignored) {}
        }
    }
}