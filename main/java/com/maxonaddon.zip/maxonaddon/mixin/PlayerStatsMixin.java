package com.maxonaddon.mixin;

import com.maxonaddon.MaxonConfig;
import com.maxonaddon.util.IPlayerStats;
import com.maxonaddon.util.TraumaType;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.EnumMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@Mixin(Player.class)
public abstract class PlayerStatsMixin implements IPlayerStats {

    // Травмы
    @Unique
    private final Map<TraumaType, Integer> maxon$traumaTimers = new EnumMap<>(TraumaType.class);

    @Override
    public int getTraumaTimer(TraumaType type) {
        return this.maxon$traumaTimers.getOrDefault(type, 0);
    }

    @Override
    public void setTraumaTimer(TraumaType type, int ticks) {
        this.maxon$traumaTimers.put(type, Math.max(0, ticks));
    }

    @Override
    public boolean hasTrauma(TraumaType type) {
        return this.getTraumaTimer(type) > 0;
    }

    // Базовые статы
    @Unique private int daotTitansKilled = 0;
    @Unique private long daotTicksPlayed = 0;
    @Unique private long daotTicksSinceDeath = 0;
    @Unique private int daotLevel = 1;
    @Unique private int daotExp = 0;
    @Unique private int daotSkillPoints = 0;
    @Unique private int daotBloodlinePoints = 0;
    @Unique private int daotTitanPoints = 0;

    // === НОВАЯ ЕДИНАЯ СИСТЕМА НАВЫКОВ ===
    @Unique
    private Set<String> unlockedSkills = new HashSet<>();

    @Override
    public Set<String> getUnlockedSkills() {
        return this.unlockedSkills;
    }

    @Override
    public void setUnlockedSkills(Set<String> skills) {
        this.unlockedSkills = new HashSet<>(skills);
    }

    @Override
    public boolean hasSkill(String skillId) {
        return this.unlockedSkills.contains(skillId);
    }

    @Override
    public void unlockSkill(String skillId) {
        this.unlockedSkills.add(skillId);
    }
    // ===================================

    @Override public int getBloodlinePoints() { return this.daotBloodlinePoints; }
    @Override public void setBloodlinePoints(int points) { this.daotBloodlinePoints = points; }
    @Override public int getTitanPoints() { return this.daotTitanPoints; }
    @Override public void setTitanPoints(int points) { this.daotTitanPoints = points; }
    @Override public void setTitansKilled(int amount) { this.daotTitansKilled = amount; }
    @Override public void setTicksPlayedTotal(long amount) { this.daotTicksPlayed = amount; }
    @Override public void setTicksSinceDeath(long amount) { this.daotTicksSinceDeath = amount; }
    @Override public int getLevel() { return this.daotLevel; }
    @Override public void setLevel(int level) { this.daotLevel = level; }
    @Override public int getExp() { return this.daotExp; }
    @Override public void setExp(int exp) { this.daotExp = exp; }
    @Override public int getSkillPoints() { return this.daotSkillPoints; }
    @Override public void setSkillPoints(int sp) { this.daotSkillPoints = sp; }

    @ModifyVariable(method = "displayClientMessage", at = @At("HEAD"), argsOnly = true)
    private Component replaceJamMessage(Component original) {
        // Перехватываем стандартное сообщение о клине (тут используется default метод из интерфейса)
        if (!this.hasOdmMastery() && original.getString().equals("ODM jammed!")) {
            return Component.translatable("gui.maxonaddon.skills.odm_required").withStyle(ChatFormatting.RED);
        }
        return original;
    }

    @Inject(method = "addAdditionalSaveData", at = @At("TAIL"))
    private void saveDaotStats(CompoundTag tag, CallbackInfo ci) {
        // Сохраняем таймеры травм
        for (TraumaType type : TraumaType.values()) {
            tag.putInt("MaxonTrauma_" + type.name(), this.getTraumaTimer(type));
        }

        tag.putInt("DaotTitansKilled", this.daotTitansKilled);
        tag.putLong("DaotTicksPlayed", this.daotTicksPlayed);
        tag.putLong("DaotTicksSinceDeath", this.daotTicksSinceDeath);
        tag.putInt("DaotLevel", this.daotLevel);
        tag.putInt("DaotExp", this.daotExp);
        tag.putInt("DaotSkillPoints", this.daotSkillPoints);
        tag.putInt("DaotBloodlinePoints", this.daotBloodlinePoints);
        tag.putInt("DaotTitanPoints", this.daotTitanPoints);

        // Сохранение новой системы навыков в виде списка
        ListTag skillsList = new ListTag();
        for (String skillId : this.unlockedSkills) {
            skillsList.add(StringTag.valueOf(skillId));
        }
        tag.put("MaxonUnlockedSkills", skillsList);
    }

    @Inject(method = "readAdditionalSaveData", at = @At("TAIL"))
    private void readDaotStats(CompoundTag tag, CallbackInfo ci) {
        // Читаем таймеры травм
        for (TraumaType type : TraumaType.values()) {
            if (tag.contains("MaxonTrauma_" + type.name())) {
                this.setTraumaTimer(type, tag.getInt("MaxonTrauma_" + type.name()));
            }
        }

        if (tag.contains("DaotTitansKilled")) {
            this.daotTitansKilled = tag.getInt("DaotTitansKilled");
            this.daotTicksPlayed = tag.getLong("DaotTicksPlayed");
            this.daotTicksSinceDeath = tag.getLong("DaotTicksSinceDeath");
        }

        if (tag.contains("DaotBloodlinePoints")) {
            this.daotBloodlinePoints = tag.getInt("DaotBloodlinePoints");
            this.daotTitanPoints = tag.getInt("DaotTitanPoints");
        }

        if (tag.contains("DaotLevel")) {
            this.daotLevel = tag.getInt("DaotLevel");
            this.daotExp = tag.getInt("DaotExp");
            this.daotSkillPoints = tag.getInt("DaotSkillPoints");
        } else {
            this.daotLevel = 1;
        }

        // Очищаем текущие скилы перед загрузкой
        this.unlockedSkills.clear();

        // Читаем новую систему
        if (tag.contains("MaxonUnlockedSkills", Tag.TAG_LIST)) {
            ListTag skillsList = tag.getList("MaxonUnlockedSkills", Tag.TAG_STRING);
            for (int i = 0; i < skillsList.size(); i++) {
                this.unlockedSkills.add(skillsList.getString(i));
            }
        }
        // МИГРАЦИЯ со старых сохранений
        else {
            if (tag.getBoolean("DaotOdmMastery")) this.unlockedSkills.add("odm_mastery");
            if (tag.getBoolean("DaotDashMastery")) this.unlockedSkills.add("dash_mastery");
            if (tag.getBoolean("DaotConnectorMastery")) this.unlockedSkills.add("connector_mastery");
            if (tag.getBoolean("UngrabingMastery")) this.unlockedSkills.add("ungrabing_mastery");
            if (tag.getBoolean("DaotBloodlineAwakening")) this.unlockedSkills.add("bloodline_awakening");
            if (tag.getBoolean("DaotShifterRegen")) this.unlockedSkills.add("shifter_regen");
        }
    }

    @Override public int getTitansKilled() { return this.daotTitansKilled; }
    @Override public void addTitanKill() { this.daotTitansKilled++; }
    @Override public long getTicksPlayedTotal() { return this.daotTicksPlayed; }

    @Override
    public void incrementTicksPlayed() {
        this.daotTicksPlayed++;
        this.daotTicksSinceDeath++;

        // Берем настройки из конфига
        int interval = MaxonConfig.get().bloodlinePointsTicks;
        int amount = MaxonConfig.get().bloodlinePointsAmount;

        // Если интервал больше нуля (защита от краша) и пришло время выдачи
        if (interval > 0 && this.daotTicksPlayed % interval == 0) {
            this.daotBloodlinePoints += amount;
        }
    }

    @Inject(method = "updatePlayerPose", at = @At("TAIL"))
    private void maxon$forceTraumaPose(CallbackInfo ci) {
        if (this.hasTrauma(com.maxonaddon.util.TraumaType.LEGS)) {
            // Превращаем 'this' в объект игрока
            net.minecraft.world.entity.player.Player player = (net.minecraft.world.entity.player.Player) (Object) this;

            // Вызываем методы у объекта player
            if (!player.isSwimming() && !player.isFallFlying() && !player.isSleeping()) {
                player.setPose(net.minecraft.world.entity.Pose.CROUCHING);
            }
        }
    }



    @Override public long getTicksSinceDeath() { return this.daotTicksSinceDeath; }
    @Override public void resetTicksSinceDeath() { this.daotTicksSinceDeath = 0; }
}