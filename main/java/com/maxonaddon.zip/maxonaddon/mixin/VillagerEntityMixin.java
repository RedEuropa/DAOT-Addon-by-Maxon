package com.maxonaddon.mixin;

import com.maxonaddon.MaxonConfig;
import com.maxonaddon.ai.ScoutOdmCombatGoal;
import com.maxonaddon.util.VillagerSkinAccessor;
import daot.BladeItem;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Villager.class)
public abstract class VillagerEntityMixin extends AbstractVillager implements VillagerSkinAccessor {

    @Unique
    private static final EntityDataAccessor<Integer> SKIN_INDEX = SynchedEntityData.defineId(Villager.class, EntityDataSerializers.INT);

    @Unique
    private final int MAX_SKINS = 5;

    @Unique
    private boolean maxonaddon$combatGoalAdded = false;

    @Unique
    private int maxon$transformTimer = 0; // Состояние таймера

    public VillagerEntityMixin(EntityType<? extends AbstractVillager> entityType, Level level) {
        super(entityType, level);
    }

    // --- РЕАЛИЗАЦИЯ ИНТЕРФЕЙСОВ ---
    @Override
    public int modid$getSkinIndex() {
        return this.entityData.get(SKIN_INDEX);
    }

    @Override
    public int maxon$getTransformTimer() {
        return this.maxon$transformTimer;
    }

    @Override
    public void maxon$setTransformTimer(int timer) {
        this.maxon$transformTimer = timer;
    }

    // --- NBT СОХРАНЕНИЕ И ЗАГРУЗКА (Объединено) ---
    @Inject(method = "addAdditionalSaveData", at = @At("TAIL"))
    private void onAddAdditionalSaveData(CompoundTag compound, CallbackInfo ci) {
        compound.putInt("CustomPlayerSkin", this.entityData.get(SKIN_INDEX));
        compound.putInt("maxon$TransformTimer", this.maxon$transformTimer);
    }

    @Inject(method = "readAdditionalSaveData", at = @At("TAIL"))
    private void onReadAdditionalSaveData(CompoundTag compound, CallbackInfo ci) {
        if (compound.contains("CustomPlayerSkin")) {
            this.entityData.set(SKIN_INDEX, compound.getInt("CustomPlayerSkin"));
        }
        if (compound.contains("maxon$TransformTimer")) {
            this.maxon$transformTimer = compound.getInt("maxon$TransformTimer");
        }
    }

    @Inject(method = "defineSynchedData", at = @At("TAIL"))
    protected void onDefineSynchedData(SynchedEntityData.Builder builder, CallbackInfo ci) {
        builder.define(SKIN_INDEX, 0);
    }

    // --- ЛОГИКА ТАЙМЕРА ОСЛАБЛЕНИЯ ---
    @Inject(method = "tick", at = @At("TAIL"))
    private void maxon$weakenedVillagerTick(CallbackInfo ci) {
        Villager villager = (Villager) (Object) this;

        if (!villager.level().isClientSide() && villager.getTags().contains("weakened_shifter_vessel")) {

            // Если таймер равен 0, значит житель только что стал ослабленным.
            // Задаем ему начальное время (например, 3600 тиков = 3 минуты)
            if (this.maxon$transformTimer <= 0 && !villager.getTags().contains("timer_initialized")) {
                this.maxon$transformTimer = 3600;
                villager.addTag("timer_initialized"); // Флаг, чтобы больше не сбрасывать таймер
            }

            if (this.maxon$transformTimer > 0) {
                this.maxon$transformTimer--;

                // Эффекты обновляем раз в секунду (каждые 20 тиков), чтобы не спамить в сеть
                if (this.maxon$transformTimer % 20 == 0) {
                    villager.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 2, false, false));
                    villager.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 40, 2, false, false));
                }
            } else {
                // Время вышло - трансформация
                villager.removeTag("weakened_shifter_vessel");
                villager.removeTag("timer_initialized");
                villager.addTag("shifter_boss_vessel");

                villager.hurt(villager.damageSources().generic(), 0.1f);
            }
        }
    }

    // --- AI И СПАВН (Оставлено без изменений) ---
    @Inject(method = "customServerAiStep", at = @At("HEAD"))
    protected void stopCowardice(CallbackInfo ci) {
        Villager villager = (Villager) (Object) this;

        if (!maxonaddon$combatGoalAdded) {
            this.goalSelector.addGoal(1, new ScoutOdmCombatGoal(villager));
            this.goalSelector.addGoal(5, new net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal(villager, 0.6));
            this.goalSelector.addGoal(6, new net.minecraft.world.entity.ai.goal.LookAtPlayerGoal(villager, net.minecraft.world.entity.player.Player.class, 8.0F));
            this.goalSelector.addGoal(7, new net.minecraft.world.entity.ai.goal.RandomLookAroundGoal(villager));
            maxonaddon$combatGoalAdded = true;
        }

        boolean isScout = villager.getTags().contains("scout_legion");
        boolean isBraveGarrison = villager.getTags().contains("brave_garrison");

        if (isScout || isBraveGarrison) {
            villager.fallDistance = 0.0f;
            if (villager.getBrain().hasMemoryValue(MemoryModuleType.IS_PANICKING)) {
                villager.getBrain().eraseMemory(MemoryModuleType.IS_PANICKING);
            }
            if (villager.getBrain().hasMemoryValue(MemoryModuleType.HURT_BY)) {
                villager.getBrain().eraseMemory(MemoryModuleType.HURT_BY);
            }
        }
    }

    @Inject(method = "finalizeSpawn", at = @At("TAIL"))
    private void onFinalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType spawnType, SpawnGroupData spawnGroupData, CallbackInfoReturnable<SpawnGroupData> cir) {
        if (!this.level().isClientSide()) {
            this.entityData.set(SKIN_INDEX, this.random.nextInt(MAX_SKINS));

            Villager v = (Villager) (Object) this;

            if (this.level().getLevelData().getGameRules().getBoolean(MaxonConfig.DO_SOLDIER_SPAWN)) {
                if (this.random.nextFloat() < 0.40f) {
                    v.addTag("garrison_soldier");

                    boolean isBrave = this.random.nextFloat() < (MaxonConfig.get().braveGarrisonChance / 100.0f);
                    if (isBrave) {
                        v.addTag("brave_garrison");
                    }

                    Item uniform = BuiltInRegistries.ITEM.get(ResourceLocation.fromNamespaceAndPath("dannys-aot", "garrison_uniform"));
                    Item gear = BuiltInRegistries.ITEM.get(ResourceLocation.fromNamespaceAndPath("dannys-aot", "odm_gear"));
                    Item boots = BuiltInRegistries.ITEM.get(ResourceLocation.fromNamespaceAndPath("dannys-aot", "odm_boots"));
                    Item blade = BuiltInRegistries.ITEM.get(ResourceLocation.fromNamespaceAndPath("dannys-aot", "blade"));

                    ItemStack stackGear = new ItemStack(gear != Items.AIR ? gear : Items.LEATHER_LEGGINGS);
                    if (gear instanceof daot.ODMGearItem) {
                        daot.ODMGearItem.setGas(stackGear, 9999);
                    }

                    ItemStack stackBladeMain = new ItemStack(blade != Items.AIR ? blade : Items.IRON_SWORD);
                    ItemStack stackBladeOff = new ItemStack(blade != Items.AIR ? blade : Items.IRON_SWORD);

                    if (blade instanceof daot.BladeItem) {
                        if (isBrave) {
                            daot.BladeItem.setBladeState(stackBladeMain, daot.BladeItem.BladeState.FRESH);
                            daot.BladeItem.setBladeState(stackBladeOff, daot.BladeItem.BladeState.FRESH);
                        } else {
                            daot.BladeItem.setBladeState(stackBladeMain, BladeItem.BladeState.EMPTY);
                            daot.BladeItem.setBladeState(stackBladeOff, BladeItem.BladeState.EMPTY);
                        }
                    }

                    v.setItemSlot(EquipmentSlot.CHEST, new ItemStack(uniform != Items.AIR ? uniform : Items.LEATHER_CHESTPLATE));
                    v.setItemSlot(EquipmentSlot.LEGS, stackGear);
                    v.setItemSlot(EquipmentSlot.FEET, new ItemStack(boots != Items.AIR ? boots : Items.LEATHER_BOOTS));
                    v.setItemSlot(EquipmentSlot.MAINHAND, stackBladeMain);
                    v.setItemSlot(EquipmentSlot.OFFHAND, stackBladeOff);

                    v.setDropChance(EquipmentSlot.CHEST, 0.0f);
                    v.setDropChance(EquipmentSlot.LEGS, 0.0f);
                    v.setDropChance(EquipmentSlot.FEET, 0.0f);
                    v.setDropChance(EquipmentSlot.MAINHAND, 0.0f);
                    v.setDropChance(EquipmentSlot.OFFHAND, 0.0f);
                }
            }
        }
    }
}