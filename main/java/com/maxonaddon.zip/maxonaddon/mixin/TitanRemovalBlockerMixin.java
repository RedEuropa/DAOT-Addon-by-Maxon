package com.maxonaddon.mixin;

import daot.*;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public class TitanRemovalBlockerMixin {

    // Внедряемся в самый корень удаления сущностей
    @Inject(method = "remove", at = @At("HEAD"), cancellable = true)
    private void blockEarlyRemoval(Entity.RemovalReason reason, CallbackInfo ci) {
        Entity self = (Entity) (Object) this;

        boolean isOurTitan = self instanceof TitanBeardEntity ||
                self instanceof CrawlerTitanEntity ||
                self instanceof YellowTitanEntity ||
                self instanceof ConnieFatherEntity ||
                self instanceof SmallTitan2Entity ||
                self instanceof SmallTitanEntity ||
                self instanceof SadTitanEntity ||
                self instanceof TitanEntity ||
                self instanceof FritzTitanEntity;

        // Запрещаем моду удалять титана, если он мертв, но 100 тиков еще не прошло!
// Внутри TitanRemovalBlockerMixin
        if (isOurTitan && self instanceof LivingEntity living && living.isDeadOrDying()) {
            if (living.deathTime < 200) { // Держим сущность в мире 10 секунд (200 тиков)
                ci.cancel();
            }
        }
    }
}