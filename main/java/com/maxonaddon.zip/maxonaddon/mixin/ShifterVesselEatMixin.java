package com.maxonaddon.mixin;

import net.minecraft.network.chat.Component;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Villager.class)
public abstract class ShifterVesselEatMixin {

    @Inject(method = "die", at = @At("HEAD"))
    private void maxon$onWeakenedVillagerDeath(DamageSource source, CallbackInfo ci) {
        Villager villager = (Villager) (Object) this;

        if (!villager.level().isClientSide() && villager.getTags().contains("weakened_shifter_vessel")) {
            if (source.getEntity() instanceof Player player) {
                player.addTag("has_shifted_before");
                player.displayClientMessage(Component.translatable("Вы успешно забрали силу титана!"), true);
            }
        }
    }
}