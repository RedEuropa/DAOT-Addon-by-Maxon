package com.maxonaddon.block.entity;

import com.maxonaddon.MaxonDaotAddon;
import com.maxonaddon.block.GasCisternaBlock;
import daot.DannysAot;
import daot.GasCanisterItem;
import daot.IceburstFurnaceBlockEntity;
import daot.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.util.GeckoLibUtil;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.HolderLookup;
import org.jetbrains.annotations.Nullable;

public class GasCisternaBlockEntity extends IceburstFurnaceBlockEntity implements GeoBlockEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public GasCisternaBlockEntity(BlockPos pos, BlockState state) {
        super(pos, state);
    }

    @Override
    public BlockEntityType<?> getType() {
        return MaxonDaotAddon.GAS_CISTERNA_ENTITY;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

    // === НАШИ НОВЫЕ АПГРЕЙДЫ ===

    // 1. Увеличиваем лимит инвентаря до 256
    @Override
    public int getMaxStackSize() {
        return 99;
    }

    // 2. Блокируем весь мусор (дерево, уголь, бамбук), разрешаем только нужное
    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        if (slot == 0) return stack.is(DannysAot.ICE_BURST_CLUSTER);
        if (slot == 1) return stack.getItem() instanceof GasCanisterItem;
        return false;
    }
    // 1. Отправляем NBT данные блока клиенту при загрузке чанка
    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return this.saveWithoutMetadata(registries);
    }

    // 2. Создаем пакет обновлений для передачи по сети
    @Nullable
    @Override
    public Packet<net.minecraft.network.protocol.game.ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    // 3. Каждый раз, когда инвентарь меняется (положили/забрали предмет),
    // принудительно рассылаем пакет обновлений всем клиентам вокруг
    @Override
    public void setChanged() {
        super.setChanged();
        if (this.level != null && !this.level.isClientSide) {
            // Флаг 3 означает: обновить блок и отправить изменения клиенту
            this.level.sendBlockUpdated(this.getBlockPos(), this.getBlockState(), this.getBlockState(), 3);
        }
    }

    // 3. Ускоренная логика работы без угля
    public static void serverTickCisterna(Level level, BlockPos pos, BlockState state, GasCisternaBlockEntity entity) {
        boolean wasLit = entity.dataAccess.get(0) > 0;
        boolean changed = false;

        ItemStack primary = entity.getItem(0);
        ItemStack secondary = entity.getItem(1);

        boolean hasCanisterRecipe = !primary.isEmpty() && primary.is(DannysAot.ICE_BURST_CLUSTER) &&
                !secondary.isEmpty() && secondary.getItem() instanceof GasCanisterItem &&
                GasCanisterItem.getGas(secondary) < 500;

        if (hasCanisterRecipe) {
            // Имитируем, что печка "горит", чтобы шли партиклы
            entity.dataAccess.set(0, 1);
            entity.dataAccess.set(1, 1);

            // УСКОРЯЕМ В 2 РАЗА (вместо +1 делаем +2)
            int progress = entity.dataAccess.get(2) + 2;
            entity.dataAccess.set(2, progress);

            // 80 - это длина полоски UI в оригинальном моде, оставляем её
            if (progress >= 80) {
                entity.dataAccess.set(2, 0); // Сбрасываем прогресс

                int gas = GasCanisterItem.getGas(secondary);
                GasCanisterItem.setGas(secondary, Math.min(gas + 25, 500));
                primary.shrink(1); // Тратим 1 кластер льда

                level.playSound(null, pos, ModSounds.STEAM_POOF, SoundSource.BLOCKS, 1.0F, 2.0F);
                changed = true;
            }
        } else {
            // Если рецепта нет - всё выключаем
            entity.dataAccess.set(2, 0);
            entity.dataAccess.set(0, 0);
        }

        // Обновляем состояние блока (вкл/выкл) для анимаций и партиклов
        boolean isLit = entity.dataAccess.get(0) > 0;
        if (wasLit != isLit) {
            changed = true;
            level.setBlock(pos, state.setValue(GasCisternaBlock.LIT, isLit), 3);
        }

        if (changed) {
            entity.setChanged();
        }
    }
}