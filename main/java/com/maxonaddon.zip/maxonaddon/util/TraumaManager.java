package com.maxonaddon.util;

import com.maxonaddon.MaxonConfig;
import com.maxonaddon.MaxonDaotAddon;
import com.maxonaddon.network.SyncTraumaPayload;
import com.maxonaddon.network.TraumaAnimationPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import daot.NapeSmokeHelper;

public class TraumaManager {

    // В новых версиях Minecraft (1.21+) модификаторы используют ResourceLocation вместо UUID.
    // Создаем уникальные ID для наших дебаффов, используя MOD_ID из главного класса.
    private static final ResourceLocation BODY_TRAUMA_ID = MaxonDaotAddon.id("body_trauma");
    private static final ResourceLocation LEGS_TRAUMA_ID = MaxonDaotAddon.id("legs_trauma");

    private static final ResourceLocation LEGS_TRAUMA_SPEED_ID = MaxonDaotAddon.id("legs_trauma_speed");
    private static final ResourceLocation LEGS_TRAUMA_JUMP_ID = MaxonDaotAddon.id("legs_trauma_jump");

    public static void applyTrauma(ServerPlayer player, TraumaType type, int durationTicks) {
        IPlayerStats stats = (IPlayerStats) player;
        stats.setTraumaTimer(type, durationTicks);

        switch (type) {
            case BODY:
                applyBodyDebuff(player);
                break;
            case ARMS:
                applyArmsDebuff(player);
                break;
            case LEGS:
                applyLegsDebuff(player);
                break;
            case HEAD:
                // Голова обрабатывается на клиенте (размытие и звук)
                // Позже добавим сюда отправку сетевого пакета.
                break;
        }
    }

    public static void syncTrauma(ServerPlayer player, TraumaType type) {
        IPlayerStats stats = (IPlayerStats) player;
        ServerPlayNetworking.send(player, new SyncTraumaPayload(type.name(), stats.getTraumaTimer(type)));
    }

    private static void applyBodyDebuff(ServerPlayer player) {
        AttributeInstance healthAttr = player.getAttribute(Attributes.MAX_HEALTH);
        if (healthAttr != null && healthAttr.getModifier(BODY_TRAUMA_ID) == null) {
            // Используем ADD_MULTIPLIED_TOTAL вместо MULTIPLY_TOTAL и убираем строку с названием
            healthAttr.addPermanentModifier(new AttributeModifier(
                    BODY_TRAUMA_ID, -0.5, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
            ));

            // Если текущее ХП больше нового максимума, опускаем его
            if (player.getHealth() > player.getMaxHealth()) {
                player.setHealth(player.getMaxHealth());
            }
        }
    }

    // Единый метод получения травмы от монстра
    public static void applyMonsterTrauma(ServerPlayer player, TraumaType type) {
        if (!player.level().getGameRules().getBoolean(MaxonConfig.ALLOW_INJURES)) {
            return;
        }

        IPlayerStats stats = (IPlayerStats) player;
        int seconds;

        if (stats.hasShifterRegen()) {
            seconds = MaxonConfig.get().shifterTraumaDurationSeconds;
        } else {
            seconds = switch (type) {
                case HEAD -> MaxonConfig.get().headTraumaDurationSeconds;
                case BODY -> MaxonConfig.get().bodyTraumaDurationSeconds;
                case ARMS -> MaxonConfig.get().armsTraumaDurationSeconds;
                case LEGS -> MaxonConfig.get().legsTraumaDurationSeconds;
            };
        }

        // === БЫСТРАЯ РЕГЕНЕРАЦИЯ (Наслаивание) ===
        double reduction = 0.0;

        if (stats.hasSkill("fast_regen_1")) {
            reduction += 0.15; // Сокращаем время на 15%
        }
        if (stats.hasSkill("fast_regen_2")) {
            reduction += 0.25; // Сокращаем еще на 25% (в сумме -40% времени)
        }

        double durationMultiplier = 1.0 - reduction;
        // Если reduction = 0.40, время умножается на 0.60
        int durationTicks = (int) (seconds * 20 * durationMultiplier);

        applyTrauma(player, type, durationTicks);
        syncTrauma(player, type);

        player.displayClientMessage(
                Component.translatable("message.maxonaddon.trauma.broken", type.name()),
                true
        );
    }
    // Случайная травма в бою с учетом конфига процентов
    public static void applyRandomTrauma(ServerPlayer player) {
        if (!player.level().getGameRules().getBoolean(MaxonConfig.ALLOW_INJURES)) {
            return;
        }

        MaxonConfig config = MaxonConfig.get();
        double headChance = config.headTraumaChance;
        double bodyChance = config.bodyTraumaChance;
        double armsChance = config.armsTraumaChance;
        double legsChance = config.legsTraumaChance;

        double totalWeight = headChance + bodyChance + armsChance + legsChance;
        if (totalWeight <= 0) return;

        double randomValue = player.getRandom().nextDouble() * totalWeight;

        TraumaType chosenType = TraumaType.LEGS; // Заглушка по умолчанию

        if (randomValue < headChance) {
            chosenType = TraumaType.HEAD;
        } else if (randomValue < headChance + bodyChance) {
            chosenType = TraumaType.BODY;
        } else if (randomValue < headChance + bodyChance + armsChance) {
            chosenType = TraumaType.ARMS;
        } else {
            chosenType = TraumaType.LEGS;
        }

        applyMonsterTrauma(player, chosenType);
    }


    private static void applyArmsDebuff(ServerPlayer player) {
        // Выбрасываем предмет из левой руки на землю
        ItemStack offhand = player.getOffhandItem();
        if (!offhand.isEmpty()) {
            player.drop(offhand.copy(), true, false);
            player.setItemInHand(InteractionHand.OFF_HAND, ItemStack.EMPTY);
        }
    }

    private static void applyLegsDebuff(ServerPlayer player) {
        AttributeInstance speedAttr = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speedAttr != null && speedAttr.getModifier(LEGS_TRAUMA_SPEED_ID) == null) {
            // -0.7 делает скорость идентичной ходьбе на шифте
            speedAttr.addPermanentModifier(new AttributeModifier(
                    LEGS_TRAUMA_SPEED_ID, -0.7, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
            ));
        }

        AttributeInstance jumpAttr = player.getAttribute(Attributes.JUMP_STRENGTH);
        if (jumpAttr != null && jumpAttr.getModifier(LEGS_TRAUMA_JUMP_ID) == null) {
            // -1.0 полностью отключает высоту прыжка (игрок не сможет прыгать вообще)
            jumpAttr.addPermanentModifier(new AttributeModifier(
                    LEGS_TRAUMA_JUMP_ID, -1.0, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
            ));
        }
    }

    // Вызывать каждый тик на сервере
    public static void tickTraumas(ServerPlayer player) {
        IPlayerStats stats = (IPlayerStats) player;
        boolean isShifterWithRegen = stats.hasShifterRegen();
        boolean hasActiveTrauma = false;

        int shifterTicksMax = MaxonConfig.get().shifterTraumaDurationSeconds * 20;

        // Внутри метода tickTraumas для каждого игрока:
        if (stats.hasTrauma(TraumaType.HEAD) || stats.hasTrauma(TraumaType.BODY)) {
            if (player.getRandom().nextInt(300) == 0) { // Примерно раз в 15 секунд
                int spasmTicks = 12; // Длительность около 0.6 сек (совпадает с длиной анимаций)

                // Замораживаем движение на сервере
                player.setDeltaMovement(0, player.getDeltaMovement().y, 0);

                // Выбираем анимацию в зависимости от того, какая травма активна
                String animToPlay = stats.hasTrauma(TraumaType.HEAD) ? "injure_head" : "injure_body";

                // Шлем пакет клиенту
                ServerPlayNetworking.send(player, new TraumaAnimationPayload(animToPlay));
            }
        }
        for (TraumaType type : TraumaType.values()) {
            int currentTimer = stats.getTraumaTimer(type);

            if (currentTimer > 0) {
                hasActiveTrauma = true;

                // Если игрок шифтер, а таймер больше положенного для шифтера — ускоряем до конфига
                if (isShifterWithRegen && currentTimer > shifterTicksMax) {
                    currentTimer = shifterTicksMax;
                    stats.setTraumaTimer(type, currentTimer);
                }

                currentTimer--;
                stats.setTraumaTimer(type, currentTimer);

                // Если время вышло - исцеляем
                if (currentTimer <= 0) {
                    healTrauma(player, type);
                    syncTrauma(player, type);
                } else if (currentTimer % 20 == 0) {
                    // Синхронизируем с клиентом каждую секунду
                    syncTrauma(player, type);
                }
            }
        }

        // === ПАР И ЗВУК ДЛЯ ШИФТЕРА ПРИ РЕГЕНЕРАЦИИ ТРАВМЫ ===
        if (isShifterWithRegen && hasActiveTrauma) {
            net.minecraft.server.level.ServerLevel serverLevel = player.serverLevel();
            int tickCount = serverLevel.getServer().getTickCount();

            // Спавним дым костра каждые 4 тика для плавного густого потока
            if (tickCount % 4 == 0) {
                serverLevel.sendParticles(
                        daot.DannysAot.NAPE_STEAM_PARTICLE, // <--- ИСПОЛЬЗУЕМ ПАР ИЗ ОРИГИНАЛЬНОГО МОДА
                        player.getX(), player.getY() + 0.5, player.getZ(),
                        2, // Количество частиц
                        0.2, 0.4, 0.2, // Небольшой разброс по сторонам
                        0.02 // Скорость подъема вверх
                );
            }

            // Звук шипения проигрываем раз в секунду (каждые 20 тиков), чтобы не оглушить игрока
            if (tickCount % 20 == 0) {
                serverLevel.playSound(null, player.getX(), player.getY(), player.getZ(),
                        daot.ModSounds.STEAM_POOF, // <--- МОЖЕШЬ ТАКЖЕ ЗАМЕНИТЬ ЗВУК НА ТИТАНОВСКИЙ, если он доступен, или оставить FIRE_EXTINGUISH
                        net.minecraft.sounds.SoundSource.PLAYERS,
                        0.05F, 1.8F);
            }
        }
    }
    // Метод для восстановления физических дебаффов после смерти/возрождения
    public static void reapplyTraumas(ServerPlayer player) {
        IPlayerStats stats = (IPlayerStats) player;

        if (stats.hasTrauma(TraumaType.BODY)) {
            applyBodyDebuff(player);
        }
        if (stats.hasTrauma(TraumaType.LEGS)) {
            applyLegsDebuff(player);
        }
    }
    public static void healTrauma(ServerPlayer player, TraumaType type) {
        IPlayerStats stats = (IPlayerStats) player;
        stats.setTraumaTimer(type, 0);

        if (type == TraumaType.BODY) {
            AttributeInstance healthAttr = player.getAttribute(Attributes.MAX_HEALTH);
            if (healthAttr != null) healthAttr.removeModifier(BODY_TRAUMA_ID);

        } else if (type == TraumaType.LEGS) {
            AttributeInstance speedAttr = player.getAttribute(Attributes.MOVEMENT_SPEED);
            if (speedAttr != null) speedAttr.removeModifier(LEGS_TRAUMA_SPEED_ID);

            AttributeInstance jumpAttr = player.getAttribute(Attributes.JUMP_STRENGTH);
            if (jumpAttr != null) jumpAttr.removeModifier(LEGS_TRAUMA_JUMP_ID);
        }
    }
}