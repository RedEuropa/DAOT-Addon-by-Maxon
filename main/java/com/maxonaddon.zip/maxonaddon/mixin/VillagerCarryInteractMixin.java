package com.maxonaddon.mixin;

import daot.DefeatedCarryTracker;
import daot.HandcuffsTracker;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Villager.class)
public abstract class VillagerCarryInteractMixin {

    @Inject(method = "mobInteract", at = @At("HEAD"), cancellable = true)
    private void maxon$allowCarryingWeakenedVillager(Player player, InteractionHand hand, CallbackInfoReturnable<InteractionResult> cir) {
        Villager villager = (Villager) (Object) this;

        if (villager.getTags().contains("weakened_shifter_vessel")) {

            if (!villager.level().isClientSide() && player instanceof ServerPlayer serverPlayer) {

                // Если житель УЖЕ сидит на ЭТОМ игроке - снимаем его
                if (villager.isPassenger() && villager.getVehicle() == player) {
                    villager.stopRiding();
                    HandcuffsTracker.uncuffEntity(villager, serverPlayer);
                }
                // Иначе - подбираем его (ВЫРЫВАЕМ из любых багов)
                else {
                    if (villager.isPassenger()) {
                        villager.stopRiding(); // Срываем с призрачной шеи
                    }

                    DefeatedCarryTracker.markDefeated(villager.getUUID());
                    HandcuffsTracker.cuffEntity(villager, serverPlayer);
                    villager.startRiding(player, true);
                }
            }

            cir.setReturnValue(InteractionResult.sidedSuccess(villager.level().isClientSide()));
        }
    }
}