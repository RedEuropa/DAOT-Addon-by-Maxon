package com.maxonaddon.event;

import com.maxonaddon.network.CarriageGuiPayload;
import com.maxonaddon.util.ICarriageData;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;

import java.util.ArrayList;

public class CarriageInteractHandler {

    // Точка леса, раз он генерируется слишком далеко для locate
    private static final BlockPos GIANT_FOREST_POS = new BlockPos(70000, 80, 70000);

    public static void register() {
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.isClientSide() || hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;

            if (entity instanceof Villager villager && villager.getTags().contains("carriage_driver")) {
                ICarriageData playerData = (ICarriageData) player;
                BlockPos npcPos = villager.blockPosition();

                // 1. Получаем ID города
                String cityId = "";
                for (String tag : villager.getTags()) {
                    if (tag.startsWith("daot_city:")) {
                        cityId = tag.replace("daot_city:", "");
                        break;
                    }
                }
                if (cityId.isEmpty()) {
                    cityId = "city_" + npcPos.getX() + "_" + npcPos.getZ();
                    villager.addTag("daot_city:" + cityId);
                }

                villager.addTag("Visited");

                // 2. Открываем город и записываем его координаты
                if (!playerData.maxon$getUnlockedCities().containsKey(cityId)) {
                    playerData.maxon$unlockCity(cityId, npcPos);
                    player.sendSystemMessage(Component.translatable("message.maxonaddon.carriage.new_route").withStyle(ChatFormatting.GREEN));
                }

                // 3. Пытаемся найти лес, если игрок ушел достаточно далеко (> 7000 блоков) и лес еще не открыт
                if (!playerData.maxon$isForestUnlocked() && world instanceof ServerLevel serverLevel) {
                    if (Math.abs(npcPos.getX()) > 7000 || Math.abs(npcPos.getZ()) > 7000) {
                        BlockPos foundForest = com.maxonaddon.util.ForestLocator.getOrFindForest(serverLevel, npcPos);

                        if (foundForest != null) {
                            playerData.maxon$setForestUnlocked(true);
                            player.sendSystemMessage(Component.translatable("message.maxonaddon.carriage.forest_found").withStyle(ChatFormatting.GOLD));
                        }
                    }
                }

                // 4. Шлем пакет для GUI
                if (player instanceof ServerPlayer serverPlayer) {
                    ServerPlayNetworking.send(serverPlayer,
                            new CarriageGuiPayload(
                                    new ArrayList<>(playerData.maxon$getUnlockedCities().keySet()),
                                    playerData.maxon$isForestUnlocked()
                            )
                    );
                }

                return InteractionResult.CONSUME;
            }
            return InteractionResult.PASS;
        });
    }
}