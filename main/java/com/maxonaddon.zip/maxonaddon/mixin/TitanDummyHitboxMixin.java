package com.maxonaddon.mixin;

import com.maxonaddon.util.LegCutState;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

@Mixin(Entity.class)
public class TitanDummyHitboxMixin {

    // ThreadLocal защищает от StackOverflow (бесконечной рекурсии),
    // когда мы сами вызываем setPos внутри перехватчика setPos.
    private static final ThreadLocal<Boolean> IS_OFFSETTING = ThreadLocal.withInitial(() -> false);

    // Кэшируем методы рефлексии, чтобы не искать их каждый тик и не нагружать сервер
    private static final Map<Class<?>, Method> METHOD_CACHE = new HashMap<>();

    @Inject(method = "setPos(DDD)V", at = @At("HEAD"), cancellable = true)
    private void interceptSetPos(double x, double y, double z, CallbackInfo ci) {
        // Если смещение уже применяется нами же — пропускаем, чтобы не зациклить
        if (IS_OFFSETTING.get()) return;

        Entity self = (Entity) (Object) this;

        // Быстрый фильтр: применяем логику только к хитбоксам мода, отсекая обычные энтити
        String className = self.getClass().getSimpleName();
        if (!className.contains("TitanNape") && !className.contains("TitanEye")) {
            return;
        }

        try {
            Class<?> clazz = self.getClass();
            Method getParentMethod = METHOD_CACHE.get(clazz);

            // Если метода нет в кэше, пытаемся его найти
            if (getParentMethod == null && !METHOD_CACHE.containsKey(clazz)) {
                try {
                    getParentMethod = clazz.getMethod("getParentTitan");
                    METHOD_CACHE.put(clazz, getParentMethod);
                } catch (NoSuchMethodException e) {
                    METHOD_CACHE.put(clazz, null); // Запоминаем, что метода нет, чтобы не искать снова
                }
            }

            if (getParentMethod != null) {
                Object parentObj = getParentMethod.invoke(self);

                if (parentObj instanceof LivingEntity parent && parent instanceof LegCutState legState) {
                    if (legState.isLegCut()) {
                        int timer = legState.getLegCutTimer();
                        float progress = 0.0F;

                        // Воспроизводим тайминги анимации
                        if (timer >= 80) {
                            progress = (100 - timer) / 20.0F;
                        } else if (timer > 20) {
                            progress = 1.0F;
                        } else {
                            progress = timer / 20.0F;
                        }

                        progress = progress * progress * (3 - 2 * progress);

                        if (progress > 0) {
                            // Расчеты смещения[cite: 1]
                            double dropOffset = parent.getBbHeight() * 0.45 * progress;
                            float yaw = (float) Math.toRadians(parent.getYRot());
                            double forwardOffset = parent.getBbWidth() * 0.8 * progress;

                            // ВАЖНО: x, y и z здесь — это координаты, на которые родитель ПЫТАЕТСЯ поставить шею.
                            // Мы просто прибавляем к ним наше смещение:
                            double targetX = x - Math.sin(yaw) * forwardOffset;
                                double targetY = y - dropOffset;
                            double targetZ = z + Math.cos(yaw) * forwardOffset;

                            // Включаем флаг защиты, устанавливаем новые координаты и выключаем флаг
                            IS_OFFSETTING.set(true);
                            self.setPos(targetX, targetY, targetZ);
                            IS_OFFSETTING.set(false);

                            // Отменяем стандартный вызов, не давая моду затереть наши расчеты
                            ci.cancel();
                        }
                    }
                }
            }
        } catch (Exception ignored) {
            // Безопасно игнорируем ошибки рефлексии
        }
    }
}