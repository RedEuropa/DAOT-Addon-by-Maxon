package com.maxonaddon.mixin;

import com.mojang.logging.LogUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mob.class)
public abstract class MobHandcuffGravityMixin {

    @Unique
    private static final Logger MAXON$LOG = LogUtils.getLogger();

    // Логи в .minecraft/logs/latest.log, префикс [MaxonAddon/VESSEL]
    @Unique
    private static final boolean MAXON$DEBUG = true;

    @Unique
    private static final int[][] MAXON$OFFSETS = {
            {0, 0}, {1, 0}, {-1, 0}, {0, 1}, {0, -1},
            {1, 1}, {1, -1}, {-1, 1}, {-1, -1}
    };

    @Unique
    private boolean maxon$loggedFirstTick = false;

    @Unique
    private int maxon$unstuckCooldown = 0;

    @Inject(method = "tick", at = @At("TAIL"))
    private void maxon$applyGravityToNoAiMobs(CallbackInfo ci) {
        Mob mob = (Mob) (Object) this;
        if (mob.level().isClientSide()) return;

        boolean isCuffed = mob.getTags().contains("handcuffed");
        boolean isWeakened = mob.getTags().contains("weakened_shifter_vessel");
        boolean isBossVessel = mob.getTags().contains("shifter_boss_vessel");

        if (!isCuffed && !isWeakened && !isBossVessel) {
            maxon$loggedFirstTick = false;
            return;
        }

        // ==========================================================
        // ЛОГИ
        // ==========================================================
        if (MAXON$DEBUG) {
            if (!maxon$loggedFirstTick) {
                maxon$loggedFirstTick = true;
                MAXON$LOG.info("[MaxonAddon/VESSEL] === ПЕРВЫЙ ТИК С ТЕГОМ === {}", maxon$dump(mob));
            } else if (mob.tickCount % 40 == 0) {
                MAXON$LOG.info("[MaxonAddon/VESSEL] {}", maxon$dump(mob));
            }
        }

        // ==========================================================
        // 1. ТРАНСПОРТ
        // Игрок несёт на руках — не вмешиваемся.
        // Побеждённый носитель (weakened_shifter_vessel) вообще не должен
        // ни на ком сидеть: срываем с любого не-игрока, живой он или нет.
        // ==========================================================
        Entity vehicle = mob.getVehicle();
        if (vehicle instanceof Player) return;

        if (vehicle != null) {
            boolean ghost = vehicle.isRemoved() || !vehicle.isAlive();

            if (isWeakened || isCuffed || ghost) {
                MAXON$LOG.info("[MaxonAddon/VESSEL] Срываю с транспорта {} [removed={}, alive={}, ghost={}]",
                        vehicle.getType().toShortString(), vehicle.isRemoved(), vehicle.isAlive(), ghost);
                mob.stopRiding();
                mob.setNoGravity(false);
                mob.hasImpulse = true;
            } else {
                return; // shifter_boss_vessel законно сидит в живом титане
            }
        }

        // ==========================================================
        // 2. ФЛАГИ
        // ==========================================================
        if (mob.isNoGravity()) {
            MAXON$LOG.info("[MaxonAddon/VESSEL] Снимаю NoGravity");
            mob.setNoGravity(false);
            mob.hasImpulse = true;
        }
        if (mob.noPhysics) {
            MAXON$LOG.info("[MaxonAddon/VESSEL] Снимаю noPhysics");
            mob.noPhysics = false;
        }

        // ==========================================================
        // 3. ВЫТАСКИВАНИЕ ИЗ БЛОКОВ (не чаще раза в 10 тиков)
        // ==========================================================
        if (maxon$unstuckCooldown > 0) {
            maxon$unstuckCooldown--;
        } else if (maxon$pushOutOfBlocks(mob)) {
            maxon$unstuckCooldown = 10;
        }

        // ==========================================================
        // 4. РУЧНАЯ ГРАВИТАЦИЯ (нужна, т.к. NoAI=1 отключает ванильный travel)
        // ==========================================================
        if (!mob.isNoAi()) return;

        Vec3 motion = mob.getDeltaMovement();
        mob.setDeltaMovement(motion.x, motion.y - 0.08D, motion.z);
        mob.move(MoverType.SELF, mob.getDeltaMovement());

        if (mob.onGround()) {
            mob.setDeltaMovement(0, 0, 0);
        } else {
            mob.setDeltaMovement(mob.getDeltaMovement().scale(0.98D));
        }

        mob.hasImpulse = true;
    }

    @Unique
    private String maxon$dump(Mob mob) {
        Entity v = mob.getVehicle();
        boolean airBelow = mob.level().getBlockState(mob.blockPosition().below()).isAir();
        return mob.getType().toShortString()
                + " uuid=" + mob.getStringUUID().substring(0, 8)
                + " tags=" + mob.getTags()
                + " NoAI=" + mob.isNoAi()
                + " NoGravity=" + mob.isNoGravity()
                + " noPhysics=" + mob.noPhysics
                + " onGround=" + mob.onGround()
                + " ПОД_НИМ_ВОЗДУХ=" + airBelow
                + " pos=" + mob.position()
                + " delta=" + mob.getDeltaMovement()
                + " vehicle=" + (v == null
                ? "НЕТ"
                : v.getType().toShortString() + "[" + v.getClass().getSimpleName()
                + ", removed=" + v.isRemoved() + ", alive=" + v.isAlive() + "]");
    }

    /** @return true, если моба реально пришлось вытаскивать из блоков */
    @Unique
    private boolean maxon$pushOutOfBlocks(Mob mob) {
        Level level = mob.level();
        if (level.noCollision(mob, mob.getBoundingBox().deflate(1.0E-4))) return false;

        BlockPos base = mob.blockPosition();

        for (int dy = 0; dy <= 10; dy++) {
            for (int[] off : MAXON$OFFSETS) {
                BlockPos candidate = base.offset(off[0], dy, off[1]);

                double x = candidate.getX() + 0.5D;
                double y = candidate.getY() + 0.05D;
                double z = candidate.getZ() + 0.5D;

                AABB target = mob.getBoundingBox().move(x - mob.getX(), y - mob.getY(), z - mob.getZ());

                if (level.noCollision(mob, target)) {
                    mob.teleportTo(x, y, z);
                    mob.setDeltaMovement(Vec3.ZERO);
                    mob.fallDistance = 0.0F;
                    mob.hasImpulse = true;
                    MAXON$LOG.info("[MaxonAddon/VESSEL] Вытащил из блоков {} -> {}", base, candidate);
                    return true;
                }
            }
        }
        return false;
    }
}