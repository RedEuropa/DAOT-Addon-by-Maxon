package com.maxonaddon.mixin;

import com.maxonaddon.util.IPlayerStats;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(Player.class)
public abstract class PlayerExhaustionMixin {

    // Снижаем затраты голода (Food Exhaustion)
    @ModifyVariable(method = "causeFoodExhaustion", at = @At("HEAD"), argsOnly = true)
    private float maxon$reduceAckermanHunger(float exhaustion) {
        Player player = (Player) (Object) this;

        // Если у игрока активирована сила Аккермана
        if (player.getTags().contains("dannys-aot:awakened_power")) {
            IPlayerStats stats = (IPlayerStats) player;

            // Наслаиваем снижение голода
            if (stats.hasSkill("ackerman_endurance_2")) {
                return exhaustion * 0.90f; // -10% голодания
            } else if (stats.hasSkill("ackerman_endurance_1")) {
                return exhaustion * 0.95f; // -5% голодания
            }
        }
        return exhaustion;
    }
}