package com.maxonaddon.util;

import com.maxonaddon.skills.ModSkill;
import java.util.Set;

public interface IPlayerStats {
    int getTitansKilled();
    void addTitanKill();
    void setTitansKilled(int amount);

    long getTicksPlayedTotal();
    void incrementTicksPlayed();
    void setTicksPlayedTotal(long amount);

    long getTicksSinceDeath();
    void resetTicksSinceDeath();
    void setTicksSinceDeath(long amount);

    int getTraumaTimer(TraumaType type);
    void setTraumaTimer(TraumaType type, int ticks);
    boolean hasTrauma(TraumaType type);

    int getLevel();
    void setLevel(int level);

    int getExp();
    void setExp(int exp);

    int getSkillPoints();
    void setSkillPoints(int skillPoints);
    int getBloodlinePoints();
    void setBloodlinePoints(int points);
    int getTitanPoints();
    void setTitanPoints(int points);

    // ===============================================
    // НОВАЯ СИСТЕМА (Хранит ID всех изученных скилов)
    // ===============================================
    Set<String> getUnlockedSkills();
    void setUnlockedSkills(Set<String> skills);
    boolean hasSkill(String skillId);
    void unlockSkill(String skillId);

    // ===============================================
    // АВТОМАТИЧЕСКАЯ СОВМЕСТИМОСТЬ СО СТАРЫМ КОДОМ
    // ===============================================
    default boolean hasOdmMastery() { return hasSkill("odm_mastery"); }
    default void setOdmMastery(boolean value) { if(value) unlockSkill("odm_mastery"); else getUnlockedSkills().remove("odm_mastery"); }

    default boolean hasDashMastery() { return hasSkill("dash_mastery"); }
    default void setDashMastery(boolean value) { if(value) unlockSkill("dash_mastery"); else getUnlockedSkills().remove("dash_mastery"); }

    default boolean hasConnectorMastery() { return hasSkill("connector_mastery"); }
    default void setConnectorMastery(boolean value) { if(value) unlockSkill("connector_mastery"); else getUnlockedSkills().remove("connector_mastery"); }

    default boolean hasUngrabingMastery() { return hasSkill("ungrabing_mastery"); }
    default void setUngrabingMastery(boolean value) { if(value) unlockSkill("ungrabing_mastery"); else getUnlockedSkills().remove("ungrabing_mastery"); }

    default boolean hasBloodlineAwakening() { return hasSkill("bloodline_awakening"); }
    default void setBloodlineAwakening(boolean value) { if(value) unlockSkill("bloodline_awakening"); else getUnlockedSkills().remove("bloodline_awakening"); }

    default boolean hasShifterRegen() { return hasSkill("shifter_regen"); }
    default void setShifterRegen(boolean value) { if(value) unlockSkill("shifter_regen"); else getUnlockedSkills().remove("shifter_regen"); }
}