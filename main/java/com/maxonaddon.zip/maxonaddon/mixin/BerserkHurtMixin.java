package com.maxonaddon.mixin;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class BerserkHurtMixin {

    @Inject(method = "hurt", at = @At("HEAD"), cancellable = true)
    private void preventHurtByOwner(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        LivingEntity self = (LivingEntity) (Object) this;

        if (self.getTags().contains("berserk_boss") && source.getEntity() instanceof Player player) {
            if (self.hasPassenger(player) || self.getTags().contains("berserk_owner_" + player.getUUID().toString())) {
                cir.setReturnValue(false);
            }
        }
    }
}