package com.maxonaddon;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleFactory;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleRegistry;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.world.level.GameRules;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public class MaxonConfig {
    // === ИГРОВЫЕ ПРАВИЛА (GAMERULES) ===
    public static GameRules.Key<GameRules.BooleanValue> DO_SOLDIER_SPAWN;
    public static GameRules.Key<GameRules.BooleanValue> ALLOW_FLARE_REINFORCEMENTS;
    public static GameRules.Key<GameRules.BooleanValue> ALLOW_FEAR_SYSTEM;
    public static GameRules.Key<GameRules.BooleanValue> ALLOW_INJURES;
    public static GameRules.Key<GameRules.BooleanValue> DO_ODM_CRACKED;

    // === ВРЕМЯ ЛЕЧЕНИЯ КОНЕЧНОСТЕЙ (В СЕКУНДАХ) ===
    public int headTraumaDurationSeconds = 300;
    public int bodyTraumaDurationSeconds = 300;
    public int armsTraumaDurationSeconds = 300;
    public int legsTraumaDurationSeconds = 300;

    // === ШАНСЫ ПОЛУЧЕНИЯ ТРАВМ (%) ===
    public double headTraumaChance = 25.0;
    public double bodyTraumaChance = 25.0;
    public double armsTraumaChance = 25.0;
    public double legsTraumaChance = 25.0;
    // === НАСТРОЙКИ ТРАВМ И УПМ ===
    public float traumaDamageThreshold = 3.0F; // Урон, от которого начинается риск травмы (по умолчанию 3)
    public double traumaChanceOnDamage = 0.3;   // Шанс травмы при получении урона (30%)

    // === ВРЕМЯ ЛЕЧЕНИЯ ДЛЯ ШИФТЕРОВ (В СЕКУНДАХ) ===
    public int shifterTraumaDurationSeconds = 5; // Ускоренное лечение шифтера (по умолчанию 5 секунд)

    // === НАСТРОЙКИ СТРАХА ===
    public int titansForFearImmunity = 3;

    // === НАСТРОЙКИ ОПЫТА И ОЧКОВ ===
    public int expPerTitanKill = 25;
    public int titanPointsPerKill = 1;
    public int bloodlinePointsAmount = 1;
    public int bloodlinePointsTicks = 1200;

    // === МЕХАНИКА ЖИТЕЛЕЙ-ШИФТЕРОВ ===
    public boolean enableVillagerShifterTransformation = true;
    public double villagerTransformationChance = 100.0;

    // === КУЛДАУНЫ И ОТРЯДЫ ===
    public int scoutReinforcementCooldown = 120;
    public int squadGroupSize = 3;
    public double braveGarrisonChance = 25.0;

    // === ШАНСЫ ПРЕВРАЩЕНИЯ В БЕРСЕРКА (%) ===
    public double attackChance = 100.0;
    public double armoredChance = 100.0;
    public double femaleChance = 100.0;
    public double beastChance = 100.0;
    public double colossalChance = 100.0;
    public double warhammerChance = 100.0;

    // === ЗДОРОВЬЕ БЕРСЕРКОВ (HP) ===
    public double attackHealth = 600.0;
    public double armoredHealth = 800.0;
    public double femaleHealth = 500.0;
    public double beastHealth = 700.0;
    public double colossalHealth = 2000.0;
    public double warhammerHealth = 600.0;

    private static MaxonConfig INSTANCE = new MaxonConfig();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static void registerGameRules() {
        DO_SOLDIER_SPAWN = GameRuleRegistry.register(
                "doSoldierSpawn",
                GameRules.Category.SPAWNING,
                GameRuleFactory.createBooleanRule(true)
        );
        DO_ODM_CRACKED = GameRuleRegistry.register(
                "doODMCracked",
                GameRules.Category.PLAYER,
                GameRuleFactory.createBooleanRule(true)
        );
        ALLOW_FLARE_REINFORCEMENTS = GameRuleRegistry.register(
                "allowFlareReinforcements",
                GameRules.Category.PLAYER,
                GameRuleFactory.createBooleanRule(true)
        );
        ALLOW_FEAR_SYSTEM = GameRuleRegistry.register(
                "allowFearSystem",
                GameRules.Category.PLAYER,
                GameRuleFactory.createBooleanRule(true)
        );
        // Регистрация нового геймрула травм (по умолчанию true)
        ALLOW_INJURES = GameRuleRegistry.register(
                "allowInjures",
                GameRules.Category.PLAYER,
                GameRuleFactory.createBooleanRule(true)
        );
    }

    public static MaxonConfig get() {
        return INSTANCE;
    }

    public static void load() {
        Path configPath = FabricLoader.getInstance().getConfigDir().resolve("maxon_addon.json");
        if (Files.exists(configPath)) {
            try (Reader reader = Files.newBufferedReader(configPath)) {
                INSTANCE = GSON.fromJson(reader, MaxonConfig.class);
            } catch (Exception e) {
                System.err.println("Ошибка чтения maxon_addon.json: " + e.getMessage());
            }
        } else {
            save();
        }
    }

    public static void save() {
        Path configPath = FabricLoader.getInstance().getConfigDir().resolve("maxon_addon.json");
        try (Writer writer = Files.newBufferedWriter(configPath)) {
            GSON.toJson(INSTANCE, writer);
        } catch (Exception e) {
            System.err.println("Ошибка записи maxon_addon.json: " + e.getMessage());
        }
    }
}