package com.maxonaddon.skills;

import org.jetbrains.annotations.Nullable;
import java.util.ArrayList;
import java.util.List;

public enum ModSkill {
    // === СОЛДАТСКИЕ НАВЫКИ ===
    ODM_MASTERY("odm_mastery", "gui.maxonaddon.skills.odm_mastery", 1, Category.SOLDIER, null, "ANY"),
    DASH("dash_mastery", "gui.maxonaddon.skills.dash", 1, Category.SOLDIER, ODM_MASTERY, "ANY"),
    CONNECTOR("connector_mastery", "gui.maxonaddon.skills.connector", 1, Category.SOLDIER, ODM_MASTERY, "ANY"),
    UNGRABING("ungrabing_mastery", "gui.maxonaddon.skills.ungrabing", 2, Category.SOLDIER, null, "ANY"),
    AGILITY_1("agility_1", "gui.maxonaddon.skills.agility_1", 1, Category.SOLDIER, null, "ANY"),
    AGILITY_2("agility_2", "gui.maxonaddon.skills.agility_2", 1, Category.SOLDIER, AGILITY_1, "ANY"),
    IRON_BONES_1("iron_bones_1", "gui.maxonaddon.skills.iron_bones_1", 1, Category.SOLDIER, null, "ANY"),
    IRON_BONES_2("iron_bones_2", "gui.maxonaddon.skills.iron_bones_2", 1, Category.SOLDIER, IRON_BONES_1, "ANY"),
    FAST_REGEN_1("fast_regen_1", "gui.maxonaddon.skills.fast_regen_1", 1, Category.SOLDIER, null, "ANY"),
    FAST_REGEN_2("fast_regen_2", "gui.maxonaddon.skills.fast_regen_2", 1, Category.SOLDIER, FAST_REGEN_1, "ANY"),

    // === НАВЫКИ ТИТАНА ===
    SHIFTER_REGEN("shifter_regen", "gui.maxonaddon.skills.shifter_regen", 50, Category.TITAN, null, "ANY"),

    // === НАВЫКИ РОДОСЛОВНОЙ (ОБЩИЕ) ===
    BLOODLINE_AWAKENING("bloodline_awakening", "gui.maxonaddon.skills.learned_awakening", 1, Category.BLOODLINE, null, "ANY"),

    // === КОРОЛЕВСКАЯ КРОВЬ ===
    ROYAL_CONTROL_1("royal_control_1", "gui.maxonaddon.skills.royal_control_1", 1, Category.BLOODLINE, null, "ROYAL"),
    ROYAL_CONTROL_2("royal_control_2", "gui.maxonaddon.skills.royal_control_2", 1, Category.BLOODLINE, ROYAL_CONTROL_1, "ROYAL"),
    ROYAL_SACRIFICE_1("royal_sacrifice_1", "gui.maxonaddon.skills.royal_sacrifice_1", 1, Category.BLOODLINE, null, "ROYAL"),
    ROYAL_SACRIFICE_2("royal_sacrifice_2", "gui.maxonaddon.skills.royal_sacrifice_2", 1, Category.BLOODLINE, ROYAL_SACRIFICE_1, "ROYAL"),

    // === АККЕРМАНЫ ===
    ACKERMAN_CONTROL_1("ackerman_control_1", "gui.maxonaddon.skills.ackerman_control_1", 1, Category.BLOODLINE, null, "ACKERMAN"),
    ACKERMAN_CONTROL_2("ackerman_control_2", "gui.maxonaddon.skills.ackerman_control_2", 1, Category.BLOODLINE, ACKERMAN_CONTROL_1, "ACKERMAN"),
    ACKERMAN_ENDURANCE_1("ackerman_endurance_1", "gui.maxonaddon.skills.ackerman_endurance_1", 1, Category.BLOODLINE, null, "ACKERMAN"),
    ACKERMAN_ENDURANCE_2("ackerman_endurance_2", "gui.maxonaddon.skills.ackerman_endurance_2", 1, Category.BLOODLINE, ACKERMAN_ENDURANCE_1, "ACKERMAN");

    public final String id;
    public final String translationKey;
    public final int cost;
    public final Category category;
    @Nullable public final ModSkill parent;
    public final String bloodlineReq; // <-- НОВЫЙ ФИЛЬТР

    ModSkill(String id, String translationKey, int cost, Category category, @Nullable ModSkill parent, String bloodlineReq) {
        this.id = id;
        this.translationKey = translationKey;
        this.cost = cost;
        this.category = category;
        this.parent = parent;
        this.bloodlineReq = bloodlineReq;
    }

    public enum Category { SOLDIER, TITAN, BLOODLINE }

    public static List<ModSkill> getByCategory(Category category) {
        List<ModSkill> list = new ArrayList<>();
        for (ModSkill skill : values()) {
            if (skill.category == category) list.add(skill);
        }
        return list;
    }

    public static ModSkill getById(String id) {
        for (ModSkill skill : values()) {
            if (skill.id.equals(id)) return skill;
        }
        return null;
    }
}