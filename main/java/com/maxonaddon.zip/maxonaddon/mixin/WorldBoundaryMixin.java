package com.maxonaddon.mixin;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.StructureManager;
import net.minecraft.server.level.WorldGenRegion;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.Pseudo;

@Pseudo
@Mixin(targets = "daot.world.ParadisChunkGenerator")
public abstract class WorldBoundaryMixin {

    @Shadow public abstract boolean isInsideVillageWalls(int x, int z);
    @Shadow public abstract boolean isOnPathFast(int x, int z);

    @Inject(method = "method_12110", at = @At("TAIL"), remap = false)
    private void onBuildSurfaceParadis(WorldGenRegion region, StructureManager structureManager, RandomState random, ChunkAccess chunk, CallbackInfo ci) {
        int topY = chunk.getMaxBuildHeight() - 1;
        int bottomY = chunk.getMinBuildHeight();

        generateUnderground(chunk, topY, bottomY);
        generateOrganicWaterAndLava(chunk, topY, bottomY);
    }

    private void generateOrganicWaterAndLava(ChunkAccess chunk, int topY, int bottomY) {
        int chunkX = chunk.getPos().x;
        int chunkZ = chunk.getPos().z;
        int startX = chunk.getPos().getMinBlockX();
        int startZ = chunk.getPos().getMinBlockZ();
        java.util.Random rand = new java.util.Random(chunk.getPos().toLong());

        // 1. Поверхностные озера и мини-реки (Дистанция 4-5 чанков)
        if (Math.abs(chunkX % 4) == 0 && Math.abs(chunkZ % 4) == 0 && rand.nextBoolean()) {
            generateSafeWaterBody(chunk, startX, startZ, topY, bottomY, rand);
        }

        // 2. Подземная лава (озера на дне пещер ИЛИ одиночные источники на потолке)
        if (Math.abs(chunkX % 3) == 1 && Math.abs(chunkZ % 3) == 1 && rand.nextInt(3) == 0) {
            generateCaveLava(chunk, startX, startZ, bottomY, rand);
        }
    }

    // Умный поиск поверхности, который ИГНОРИРУЕТ деревья и листву (чтобы вода не спавнилась в небе)
    private int getTrueGroundY(ChunkAccess chunk, int x, int z, int topY, int bottomY) {
        int y = topY;
        while (y > bottomY) {
            BlockState state = chunk.getBlockState(new BlockPos(x, y, z));
            if (state.is(Blocks.GRASS_BLOCK) || state.is(Blocks.DIRT) || state.is(Blocks.STONE) ||
                    state.is(Blocks.SAND) || state.is(Blocks.GRAVEL) || state.is(Blocks.COARSE_DIRT) ||
                    state.is(Blocks.PODZOL) || state.is(Blocks.DEEPSLATE)) {
                return y;
            }
            y--;
        }
        return bottomY;
    }

    private void generateSafeWaterBody(ChunkAccess chunk, int startX, int startZ, int topY, int bottomY, java.util.Random rand) {
        // Генерируем 2-4 смещенных центра для создания формы "червяка" (мини-реки) или неровного озера
        int nodes = 2 + rand.nextInt(3);
        int[] cx = new int[nodes];
        int[] cz = new int[nodes];
        double[] r = new double[nodes];

        cx[0] = 8; cz[0] = 8; r[0] = 2.5 + rand.nextDouble() * 2.0;
        for (int i = 1; i < nodes; i++) {
            cx[i] = cx[i-1] + rand.nextInt(7) - 3; // Смещение от предыдущего центра
            cz[i] = cz[i-1] + rand.nextInt(7) - 3;
            r[i] = 2.0 + rand.nextDouble() * 2.5;
        }

        // 1. Проверяем всю зону: ищем самую низкую точку земли и проверяем наличие дорог/стен
        int minY = topY;
        int maxY = bottomY;

        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                boolean inFootprint = false;
                for (int i = 0; i < nodes; i++) {
                    if (Math.pow(lx - cx[i], 2) + Math.pow(lz - cz[i], 2) <= (r[i] + 1) * (r[i] + 1)) {
                        inFootprint = true;
                        break;
                    }
                }

                if (inFootprint) {
                    int worldX = startX + lx;
                    int worldZ = startZ + lz;

                    // Если будущее озеро задевает город или дорогу - мгновенная отмена генерации
                    if (isInsideVillageWalls(worldX, worldZ) || isOnPathFast(worldX, worldZ)) {
                        return;
                    }

                    int y = getTrueGroundY(chunk, worldX, worldZ, topY, bottomY);
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }
        }

        // Защита от спавна на крутых склонах (чтобы не было некрасивых вертикальных срезов гор)
        if (maxY - minY > 4) return;

        // Если в самом низком месте уже есть вода, отменяем генерацию
        if (chunk.getBlockState(new BlockPos(startX + 8, minY, startZ + 8)).is(Blocks.WATER)) return;

        // Уровень воды строго ниже САМОЙ НИЗКОЙ точки земли в радиусе. Озеро никогда не выльется из берегов!
        int waterLevel = minY - 1;
        int depth = 2 + rand.nextInt(2);

        BlockState[] borderStates = { Blocks.SAND.defaultBlockState(), Blocks.DIRT.defaultBlockState(), Blocks.GRAVEL.defaultBlockState() };
        BlockState border = borderStates[rand.nextInt(borderStates.length)];

        // 2. Выкапываем чашу и заливаем воду
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                boolean isWater = false;
                boolean isBank = false;

                for (int i = 0; i < nodes; i++) {
                    double distSq = Math.pow(lx - cx[i], 2) + Math.pow(lz - cz[i], 2);
                    if (distSq <= r[i] * r[i]) isWater = true;
                    else if (distSq <= (r[i] + 1.5) * (r[i] + 1.5)) isBank = true;
                }

                int worldX = startX + lx;
                int worldZ = startZ + lz;
                int localY = getTrueGroundY(chunk, worldX, worldZ, topY, bottomY);

                if (isWater) {
                    // Очищаем блоки (землю/воздух) над водой, формируя углубление
                    for (int y = localY; y > waterLevel; y--) {
                        chunk.setBlockState(new BlockPos(worldX, y, worldZ), Blocks.AIR.defaultBlockState(), false);
                    }
                    // Заполняем водой саму чашу
                    for (int y = waterLevel; y > waterLevel - depth; y--) {
                        chunk.setBlockState(new BlockPos(worldX, y, worldZ), Blocks.WATER.defaultBlockState(), false);
                    }
                    // Кладем песок/гравий/грязь на дно
                    chunk.setBlockState(new BlockPos(worldX, waterLevel - depth, worldZ), border, false);
                }
                else if (isBank && localY >= waterLevel) {
                    // Украшаем берега
                    BlockPos pos = new BlockPos(worldX, localY, worldZ);
                    chunk.setBlockState(pos, border, false);

                    // Редкий тростник на берегу
                    if (localY == waterLevel && rand.nextInt(5) == 0 && (border.is(Blocks.SAND) || border.is(Blocks.DIRT))) {
                        chunk.setBlockState(pos.above(), Blocks.SUGAR_CANE.defaultBlockState(), false);
                    }
                }
            }
        }
    }

    private void generateCaveLava(ChunkAccess chunk, int startX, int startZ, int bottomY, java.util.Random rand) {
        int cx = 8 + rand.nextInt(4) - 2;
        int cz = 8 + rand.nextInt(4) - 2;

        // 30% шанс сгенерировать одиночный "лава-пад" (стекающий источник на потолке)
        if (rand.nextInt(100) < 30) {
            for (int y = bottomY + 40; y > bottomY + 10; y--) {
                BlockPos pos = new BlockPos(startX + cx, y, startZ + cz);
                // Ищем каменный потолок пещеры
                if (chunk.getBlockState(pos).isAir() && (chunk.getBlockState(pos.above()).is(Blocks.STONE) || chunk.getBlockState(pos.above()).is(Blocks.DEEPSLATE))) {
                    chunk.setBlockState(pos, Blocks.LAVA.defaultBlockState(), false);
                    return; // Заспавнили источник и вышли
                }
            }
            return;
        }

        // 70% шанс на классическое озеро лавы на ДНЕ пещеры
        int y = bottomY + 10 + rand.nextInt(30);
        BlockPos center = new BlockPos(startX + cx, y, startZ + cz);
        if (!chunk.getBlockState(center).isAir()) return;

        // ИЩЕМ НАСТОЯЩИЙ ПОЛ ПЕЩЕРЫ, чтобы лава не висела в воздухе (как на 3-м скрине)
        int floorY = y;
        while (floorY > bottomY && chunk.getBlockState(new BlockPos(startX + cx, floorY, startZ + cz)).isAir()) {
            floorY--;
        }

        // Формируем озерцо лавы, врезанное в пол
        int radius = 2 + rand.nextInt(3);
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                if (dx * dx + dz * dz <= radius * radius) {
                    int lx = cx + dx;
                    int lz = cz + dz;
                    if (lx >= 0 && lx < 16 && lz >= 0 && lz < 16) {
                        for (int dy = 0; dy >= -1; dy--) {
                            BlockPos pos = new BlockPos(startX + lx, floorY + dy, startZ + lz);
                            BlockState state = chunk.getBlockState(pos);

                            if (dy == 0 && (state.is(Blocks.STONE) || state.is(Blocks.DEEPSLATE))) {
                                chunk.setBlockState(pos.above(), Blocks.AIR.defaultBlockState(), false);
                                chunk.setBlockState(pos, Blocks.LAVA.defaultBlockState(), false);
                            } else if (dy == -1 && (state.is(Blocks.STONE) || state.is(Blocks.DEEPSLATE) || state.isAir())) {
                                chunk.setBlockState(pos, Blocks.LAVA.defaultBlockState(), false);
                            }
                        }
                    }
                }
            }
        }
    }

    // --- ГЕНЕРАЦИЯ ДЛИННЫХ ТУННЕЛЕЙ И ВОРОНОК ---
    private void generateUnderground(ChunkAccess chunk, int topY, int bottomY) {
        int startX = chunk.getPos().getMinBlockX();
        int startZ = chunk.getPos().getMinBlockZ();
        java.util.Random rand = new java.util.Random(chunk.getPos().toLong());

        // 1. Непрерывные трубчатые туннели
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                int worldX = startX + x;
                int worldZ = startZ + z;

                // ЗАЩИТА ГОРОДА: пропускаем генерацию пустот, если мы находимся внутри стен
                if (isInsideVillageWalls(worldX, worldZ)) {
                    continue;
                }

                int surfaceY = topY;
                while (surfaceY > bottomY && chunk.getBlockState(new BlockPos(worldX, surfaceY, worldZ)).isAir()) {
                    surfaceY--;
                }

                // Маска: разрешаем генерировать пещеры только блоками
                double mask = Math.sin(worldX * 0.01) + Math.cos(worldZ * 0.01);

                if (mask > 0.5) {
                    for (int y = surfaceY - 5; y > bottomY + 2; y--) {

                        double nx = worldX * 0.02 + Math.sin(y * 0.05);
                        double ny = y * 0.03;
                        double nz = worldZ * 0.02 + Math.cos(y * 0.05);

                        double val1 = Math.sin(nx) + Math.cos(ny) + Math.sin(nz);
                        double val2 = Math.cos(nx) + Math.sin(ny) + Math.cos(nz);

                        if (Math.abs(val1) < 0.5 && Math.abs(val2) < 0.5) {
                            BlockPos pos = new BlockPos(worldX, y, worldZ);
                            BlockState state = chunk.getBlockState(pos);

                            if (!state.isAir() && !state.is(Blocks.BEDROCK) && !state.is(Blocks.WATER) && !state.is(Blocks.LAVA)
                                    && !state.is(Blocks.SAND) && !state.is(Blocks.SANDSTONE)) {
                                chunk.setBlockState(pos, Blocks.AIR.defaultBlockState(), false);
                            }
                        }
                    }
                }
            }
        }

        // 2. Спуски (Карстовые провалы)
        if (rand.nextInt(25) == 0) { // Сделал шанс спавна немного реже
            int cx = rand.nextInt(16);
            int cz = rand.nextInt(16);
            int worldX = startX + cx;
            int worldZ = startZ + cz;

            // Запрет провалов в городе
            if (!isInsideVillageWalls(worldX, worldZ)) {
                int surfaceY = topY;
                while (surfaceY > bottomY && chunk.getBlockState(new BlockPos(worldX, surfaceY, worldZ)).isAir()) {
                    surfaceY--;
                }

                if (surfaceY > 51) {
                    int depth = rand.nextInt(40) + 20;
                    double radius = 4.0 + rand.nextDouble() * 2.0;

                    for (int y = surfaceY; y > surfaceY - depth && y > bottomY + 2; y--) {
                        int ox = cx + (int)(Math.sin(y * 0.1) * 5);
                        int oz = cz + (int)(Math.cos(y * 0.1) * 5);

                        for (int dx = -8; dx <= 8; dx++) {
                            for (int dz = -8; dz <= 8; dz++) {
                                if (dx * dx + dz * dz <= radius * radius) {
                                    int lx = ox + dx;
                                    int lz = oz + dz;
                                    if (lx >= 0 && lx < 16 && lz >= 0 && lz < 16) {
                                        BlockPos pos = new BlockPos(startX + lx, y, startZ + lz);
                                        BlockState state = chunk.getBlockState(pos);

                                        if (!state.isAir() && !state.is(Blocks.BEDROCK) && !state.is(Blocks.WATER) && !state.is(Blocks.LAVA)
                                                && !state.is(Blocks.SAND) && !state.is(Blocks.SANDSTONE)) {
                                            chunk.setBlockState(pos, Blocks.AIR.defaultBlockState(), false);
                                        }
                                    }
                                }
                            }
                        }
                        radius -= 0.05;
                        if (radius < 2.0) radius = 2.0;
                    }
                }
            }
        }

        // 3. Генерация новых руд (Жестко ограничено для баланса)
        generateVein(chunk, Blocks.COAL_ORE.defaultBlockState(), 10, 6, 0, 80, rand, startX, startZ);
        generateVein(chunk, Blocks.IRON_ORE.defaultBlockState(), 8, 5, -20, 60, rand, startX, startZ);
        generateVein(chunk, Blocks.COPPER_ORE.defaultBlockState(), 6, 5, -10, 50, rand, startX, startZ);
        generateVein(chunk, Blocks.GOLD_ORE.defaultBlockState(), 3, 4, -40, 30, rand, startX, startZ);
        generateVein(chunk, Blocks.LAPIS_ORE.defaultBlockState(), 2, 4, -60, 30, rand, startX, startZ);
        generateVein(chunk, Blocks.REDSTONE_ORE.defaultBlockState(), 4, 4, -60, 15, rand, startX, startZ);
        generateVein(chunk, Blocks.DIAMOND_ORE.defaultBlockState(), 2, 3, -60, 12, rand, startX, startZ);
    }

    private void generateVein(ChunkAccess chunk, BlockState ore, int veinsPerChunk, int veinSize, int minY, int maxY, java.util.Random rand, int minX, int minZ) {
        for (int i = 0; i < veinsPerChunk; i++) {
            int startX = rand.nextInt(16);
            int startZ = rand.nextInt(16);
            int startY = minY + rand.nextInt(Math.max(1, maxY - minY + 1));

            for (int v = 0; v < veinSize; v++) {
                int offsetX = startX + rand.nextInt(3) - 1;
                int offsetZ = startZ + rand.nextInt(3) - 1;
                int offsetY = startY + rand.nextInt(3) - 1;

                if (offsetX >= 0 && offsetX <= 15 && offsetZ >= 0 && offsetZ <= 15) {
                    BlockPos pos = new BlockPos(minX + offsetX, offsetY, minZ + offsetZ);
                    BlockState current = chunk.getBlockState(pos);

                    if (current.is(Blocks.STONE) || current.is(Blocks.DEEPSLATE)) {
                        chunk.setBlockState(pos, ore, false);
                    }
                }
            }
        }
    }
}