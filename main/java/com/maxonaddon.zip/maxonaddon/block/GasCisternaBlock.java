package com.maxonaddon.block;

import com.maxonaddon.MaxonDaotAddon;
import com.mojang.serialization.MapCodec;
import daot.IceburstFurnaceBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

public class GasCisternaBlock extends BaseEntityBlock {
    public static final MapCodec<GasCisternaBlock> CODEC = simpleCodec(GasCisternaBlock::new);

    // Свойства блока
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    public static final BooleanProperty LIT = BlockStateProperties.LIT; // <-- Добавили свойство LIT

    private static final VoxelShape SHAPE = Block.box(2.0, 0.0, 2.0, 14.0, 30.0, 14.0);

    public GasCisternaBlock(Properties properties) {
        super(properties
                .strength(3.5F, 3.5F) // Твердость и сопротивление печки
                .requiresCorrectToolForDrops() // Обязательно требовать кирку
                .sound(SoundType.METAL) // Металлические звуки и партиклы
        );

        this.registerDefaultState(this.stateDefinition.any()
                .setValue(FACING, Direction.NORTH)
                .setValue(LIT, false));
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide) {
            return null;
        }
        // ВЫЗЫВАЕМ НАШ УСКОРЕННЫЙ МЕТОД
        return createTickerHelper(type, MaxonDaotAddon.GAS_CISTERNA_ENTITY,
                com.maxonaddon.block.entity.GasCisternaBlockEntity::serverTickCisterna
        );
    }
    // 2. ВЫБРАСЫВАЕМ ВЕЩИ ПРИ РАЗРУШЕНИИ БЛОКА
    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock())) {
            BlockEntity blockEntity = level.getBlockEntity(pos);
            // Если внутри есть инвентарь печки — выплевываем предметы на землю
            if (blockEntity instanceof IceburstFurnaceBlockEntity furnace) {
                if (level instanceof ServerLevel) {
                    Containers.dropContents(level, pos, furnace);
                }
                level.updateNeighbourForOutputSignal(pos, this);
            }
            super.onRemove(state, level, pos, newState, movedByPiston);
        }
    }



    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    // Регистрируем ОБА свойства в блоке
    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, LIT); // <-- Добавили LIT в регистрацию
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        // При установке блок смотрит на игрока, и он по умолчанию выключен
        return this.defaultBlockState()
                .setValue(FACING, context.getHorizontalDirection().getOpposite())
                .setValue(LIT, false);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.ENTITYBLOCK_ANIMATED;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new com.maxonaddon.block.entity.GasCisternaBlockEntity(pos, state);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!level.isClientSide) {
            BlockEntity blockEntity = level.getBlockEntity(pos);
            if (blockEntity instanceof net.minecraft.world.MenuProvider menuProvider) {
                player.openMenu(menuProvider);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}