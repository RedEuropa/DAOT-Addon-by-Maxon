package com.maxonaddon;

import java.util.ArrayList;
import java.util.UUID;

import com.maxonaddon.command.SpawnCarriageCommand;
import com.maxonaddon.event.CarriageInteractHandler;
import com.maxonaddon.event.CarriageSpawner;
import com.maxonaddon.skills.ModSkill;
import com.maxonaddon.item.ThunderGunItem;
import com.maxonaddon.mixin.TestShifterTitanQteMixin;
import com.maxonaddon.network.VillagerPreshiftPayload;
import com.maxonaddon.util.IJawQteHandler;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import com.maxonaddon.block.GasCisternaBlock;
import com.maxonaddon.block.entity.GasCisternaBlockEntity;
import com.maxonaddon.command.GarrisonSpawnCommand;
import com.maxonaddon.command.ScoutSpawnCommand;
import com.maxonaddon.command.StatsCommand;
import com.maxonaddon.entity.ModEntities;
import com.maxonaddon.entity.TitanBoulderEntity;
import com.maxonaddon.item.GasCisternaItem;
import com.maxonaddon.network.*;
import com.maxonaddon.util.IPlayerStats;
import com.maxonaddon.util.TraumaManager;
import daot.*;
import daot.network.ODMJamPayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityCombatEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Map;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import com.maxonaddon.network.CarriageTeleportPayload;
import com.maxonaddon.util.ICarriageData;
import daot.BladeBlockTracker;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;


public class MaxonDaotAddon implements ModInitializer {
	public static final String MOD_ID = "maxon-daot-addon";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);


	public static final SimpleParticleType TITAN_STEAM = FabricParticleTypes.simple();
	public static final Block GAS_CISTERNA = new GasCisternaBlock(BlockBehaviour.Properties.of().noOcclusion());
	public static final Item GAS_CISTERNA_ITEM = new GasCisternaItem(GAS_CISTERNA, new Item.Properties());
	public static final Item THUNDER_GUN_ITEM = new ThunderGunItem(new Item.Properties().stacksTo(1));
	public static final BlockEntityType<GasCisternaBlockEntity> GAS_CISTERNA_ENTITY = Registry.register(
			BuiltInRegistries.BLOCK_ENTITY_TYPE,
			ResourceLocation.fromNamespaceAndPath(MOD_ID, "gas_cisterna"),
			FabricBlockEntityTypeBuilder.create(GasCisternaBlockEntity::new, GAS_CISTERNA).build()
	);

	public static final java.util.Map<java.util.UUID, Integer> blockStartTicks = new java.util.HashMap<>();

	// === КУЛДАУН ДЛЯ ТИХОГО КЛИНА УПМ ===
	private static final java.util.Map<java.util.UUID, Long> silentJamCooldowns = new java.util.HashMap<>();

	@Override
	public void onInitialize() {
		LOGGER.info("Загрузка MaxonDaotAddon...");
		ModEntities.register();
		registerCommands();
		PayloadTypeRegistry.playS2C().register(LegCutSyncPayload.TYPE, LegCutSyncPayload.CODEC);

		PayloadTypeRegistry.playC2S().register(ThunderGunActionPayload.TYPE, ThunderGunActionPayload.CODEC);

		// Добавь это в инициализатор мода:
		BiomeModifications.addSpawn(
				BiomeSelectors.all(), // Можно заменить на селектор конкретного биома Парадиса
				MobCategory.CREATURE,
				EntityType.CHICKEN,
				10, 2, 4 // Вес, минимальная группа, максимальная группа
		);

		ServerPlayNetworking.registerGlobalReceiver(ThunderGunActionPayload.TYPE, (payload, context) -> {
			context.server().execute(() -> {
				ServerPlayer player = context.player();
				if (player == null) return;

				if (payload.actionType() == 0) {
					tryLoadThunderGun(player, InteractionHand.MAIN_HAND);
					tryLoadThunderGun(player, InteractionHand.OFF_HAND);
				} else if (payload.actionType() == 2) {
					tryUnloadThunderGun(player, InteractionHand.MAIN_HAND);
					tryUnloadThunderGun(player, InteractionHand.OFF_HAND);
				} else if (payload.actionType() == 1) {
					InteractionHand hand = (payload.hand() == 1) ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND;
					ItemStack stack = player.getItemInHand(hand);

					// СТРОГАЯ ПРОВЕРКА: Разрешаем выстрел ТОЛЬКО нашему предмету
					if (stack.getItem() == MaxonDaotAddon.THUNDER_GUN_ITEM) {
						int loaded = com.maxonaddon.item.ThunderGunItem.getLoadedSpears(stack);
						if (loaded > 0 || player.isCreative()) {
							com.maxonaddon.item.ThunderGunItem.shootSpear(player.level(), player, stack, loaded);
						}
					}
				}
			});
		});
		// === 1. РЕГИСТРАЦИЯ СЕТЕВЫХ ПАКЕТОВ (СНАЧАЛА ЭТО) ===
		PayloadTypeRegistry.playC2S().register(RequestStatsPayload.TYPE, RequestStatsPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(ForceDetachPayload.TYPE, ForceDetachPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(DashPayload.TYPE, DashPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(TraumaAnimationPayload.TYPE, TraumaAnimationPayload.STREAM_CODEC);
		PayloadTypeRegistry.playC2S().register(BackDashPayload.TYPE, BackDashPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(RequestJamPayload.TYPE, RequestJamPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(StartHostileQtePayload.TYPE, StartHostileQtePayload.CODEC);
		PayloadTypeRegistry.playS2C().register(StopHostileQtePayload.TYPE, StopHostileQtePayload.CODEC);
		PayloadTypeRegistry.playC2S().register(HitQteKeyPayload.TYPE, HitQteKeyPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(SyncFearStatsPayload.TYPE, SyncFearStatsPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(OpenStatsScreenPayload.TYPE, OpenStatsScreenPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(BuySkillPayload.TYPE, BuySkillPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(SyncSkillsPayload.TYPE, SyncSkillsPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(ResetSkillsPayload.TYPE, ResetSkillsPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(SilentJamPayload.TYPE, SilentJamPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(SyncTraumaPayload.TYPE, SyncTraumaPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(VillagerPreshiftPayload.TYPE, VillagerPreshiftPayload.STREAM_CODEC);
		PayloadTypeRegistry.playS2C().register(JawQteStatePayload.TYPE, JawQteStatePayload.CODEC);
		PayloadTypeRegistry.playC2S().register(JawQteInputPayload.TYPE, JawQteInputPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(VillagerHookSyncPayload.TYPE, VillagerHookSyncPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(CarriageGuiPayload.TYPE, CarriageGuiPayload.STREAM_CODEC);
		PayloadTypeRegistry.playC2S().register(CarriageTeleportPayload.TYPE, CarriageTeleportPayload.STREAM_CODEC);
		PayloadTypeRegistry.playC2S().register(OdmSupplyInteractPayload.TYPE, OdmSupplyInteractPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(ReloadGearPayload.TYPE, ReloadGearPayload.CODEC);


		net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
			com.maxonaddon.command.SpawnBossCommand.register(dispatcher);
			com.maxonaddon.command.StatsCommand.register(dispatcher);
			com.maxonaddon.command.RumblingCommand.register(dispatcher);
			com.maxonaddon.command.SpawnPoweredVillagerCommand.register(dispatcher);
			ScoutSpawnCommand.register(dispatcher);
			GarrisonSpawnCommand.register(dispatcher);

		});

		// === ПЕРЕХВАТ ОРИГИНАЛЬНОЙ ПЕРЕЗАРЯДКИ ИЗ DANNYS-AOT ===
		// 1. Снимаем регистрацию с оригинальных обработчиков мода
		ServerPlayNetworking.unregisterGlobalReceiver(daot.network.BladeReloadPayload.TYPE.id());
		ServerPlayNetworking.unregisterGlobalReceiver(daot.network.APGReloadPayload.TYPE.id());

		// 2. Регистрируем наши собственные обработчики на те же самые пакеты
		ServerPlayNetworking.registerGlobalReceiver(daot.network.BladeReloadPayload.TYPE, (payload, context) -> {
			context.server().execute(() -> {
				if (context.player() != null) performMaxonReload(context.player());
			});
		});

		ServerPlayNetworking.registerGlobalReceiver(daot.network.APGReloadPayload.TYPE, (payload, context) -> {
			context.server().execute(() -> {
				if (context.player() != null) performMaxonReload(context.player());
			});
		});


		// 2. Перезарядка (когда нажали R)
		ServerPlayNetworking.registerGlobalReceiver(ReloadGearPayload.TYPE, (payload, context) -> {
			context.server().execute(() -> {
				ServerPlayer player = context.player();
				if (player == null) return;

				ItemStack legItem = player.getItemBySlot(EquipmentSlot.LEGS);
				boolean isOdm = legItem.getItem() instanceof daot.ODMGearItem;
				boolean isApg = legItem.getItem() instanceof daot.ODMAPGItem;
				if (!isOdm && !isApg) return;

				net.minecraft.world.item.component.ItemContainerContents contents = legItem.getOrDefault(net.minecraft.core.component.DataComponents.CONTAINER, net.minecraft.world.item.component.ItemContainerContents.EMPTY);
				net.minecraft.core.NonNullList<ItemStack> items = net.minecraft.core.NonNullList.withSize(2, ItemStack.EMPTY);
				contents.copyInto(items);

				boolean inventoryChanged = false;

				// Проходим по главной и левой руке
				InteractionHand[] hands = {InteractionHand.MAIN_HAND, InteractionHand.OFF_HAND};
				for (InteractionHand hand : hands) {
					ItemStack handStack = player.getItemInHand(hand);

					// Перезарядка УПМ (Мечи)
					if (isOdm && handStack.getItem() instanceof daot.BladeItem) {
						if (daot.BladeItem.getBladeState(handStack) == daot.BladeItem.BladeState.EMPTY) {
							for (int i = 0; i < items.size(); i++) {
								ItemStack supplyStack = items.get(i);
								// Теперь мы ищем BladeComponentItem!
								if (supplyStack.getItem() instanceof daot.BladeComponentItem && supplyStack.getCount() > 0) {
									supplyStack.shrink(1); // Тратим клинок
									inventoryChanged = true;
									daot.BladeItem.reloadBlade(handStack); // Восстанавливаем клинок
									player.level().playSound(null, player.getX(), player.getY(), player.getZ(), net.minecraft.sounds.SoundEvents.IRON_DOOR_OPEN, net.minecraft.sounds.SoundSource.PLAYERS, 1.0F, 1.5F);
									break;
								}
							}
						}
					}

					// Перезарядка АПГ (Огнестрел)
					if (isApg && handStack.getItem() instanceof daot.APGGunItem) {
						if (!daot.APGGunItem.isLoaded(handStack)) {
							for (int i = 0; i < items.size(); i++) {
								ItemStack supplyStack = items.get(i);
								// Ищем картридж APGCartridgeItem
								if (supplyStack.getItem() instanceof daot.APGCartridgeItem && supplyStack.getCount() > 0) {
									supplyStack.shrink(1);
									inventoryChanged = true;
									daot.APGGunItem.setLoaded(handStack, true); // Заряжаем пушку
									player.level().playSound(null, player.getX(), player.getY(), player.getZ(), net.minecraft.sounds.SoundEvents.CROSSBOW_LOADING_END, net.minecraft.sounds.SoundSource.PLAYERS, 1.0F, 1.5F);
									break;
								}
							}
						}
					}
				}

				if (inventoryChanged) {
					legItem.set(net.minecraft.core.component.DataComponents.CONTAINER, net.minecraft.world.item.component.ItemContainerContents.fromItems(items));
				}
			});
		});

// 1. Положить/Взять предметы из брони
		ServerPlayNetworking.registerGlobalReceiver(OdmSupplyInteractPayload.TYPE, (payload, context) -> {
			context.server().execute(() -> {
				ServerPlayer player = context.player();
				if (player == null) return;

				com.maxonaddon.util.IPlayerStats stats = (com.maxonaddon.util.IPlayerStats) player;
				ItemStack legItem = player.getItemBySlot(EquipmentSlot.LEGS);
				boolean isOdm = legItem.getItem() instanceof daot.ODMGearItem;
				boolean isApg = legItem.getItem() instanceof daot.ODMAPGItem;
				if (!isOdm && !isApg) return;

				net.minecraft.world.item.component.ItemContainerContents contents = legItem.getOrDefault(net.minecraft.core.component.DataComponents.CONTAINER, net.minecraft.world.item.component.ItemContainerContents.EMPTY);
				net.minecraft.core.NonNullList<ItemStack> items = net.minecraft.core.NonNullList.withSize(2, ItemStack.EMPTY);
				contents.copyInto(items);

				ItemStack cursorStack = player.containerMenu.getCarried();
				ItemStack slotStack = items.get(payload.slotIndex());

				if (cursorStack.isEmpty()) {
					if (!slotStack.isEmpty()) {
						ItemStack toGive = slotStack.copy();
						items.set(payload.slotIndex(), ItemStack.EMPTY);
						if (!player.getInventory().add(toGive)) {
							player.drop(toGive, false);
						}
					}
				} else {
					boolean isBlade = cursorStack.getItem() instanceof daot.BladeComponentItem;
					boolean isCartridge = cursorStack.getItem() instanceof daot.APGCartridgeItem;

					int maxLimit = 0;

					ItemStack otherSlot = items.get(payload.slotIndex() == 0 ? 1 : 0);
					boolean otherIsBlade = otherSlot.getItem() instanceof daot.BladeComponentItem;
					boolean otherIsCartridge = otherSlot.getItem() instanceof daot.APGCartridgeItem;

					// СИММЕТРИЧНАЯ ЛОГИКА
					if (isOdm) {
						if (isBlade && !otherIsCartridge) maxLimit = 2; // Стандартный УПМ
						else if (isCartridge && stats.hasConnectorMastery() && !otherIsBlade) maxLimit = 3; // УПМ с огнестрелом
					} else if (isApg) {
						if (isCartridge && !otherIsBlade) maxLimit = 3; // Стандартный АПГ
						else if (isBlade && stats.hasConnectorMastery() && !otherIsCartridge) maxLimit = 2; // АПГ с клинками
					}

					if (maxLimit == 0) return; // Блокируем неверный предмет или смешивание

					if (slotStack.isEmpty()) {
						int amountToPut = Math.min(cursorStack.getCount(), maxLimit);
						items.set(payload.slotIndex(), cursorStack.split(amountToPut));
					} else if (ItemStack.isSameItemSameComponents(cursorStack, slotStack)) {
						int space = maxLimit - slotStack.getCount();
						if (space > 0) {
							int toAdd = Math.min(cursorStack.getCount(), space);
							slotStack.grow(toAdd);
							cursorStack.shrink(toAdd);
						}
					} else {
						if (cursorStack.getCount() <= maxLimit) {
							ItemStack temp = slotStack.copy();
							items.set(payload.slotIndex(), cursorStack.copy());
							cursorStack = temp;
						}
					}
				}

				legItem.set(net.minecraft.core.component.DataComponents.CONTAINER, net.minecraft.world.item.component.ItemContainerContents.fromItems(java.util.List.copyOf(items)));
				player.containerMenu.setCarried(cursorStack);
				player.containerMenu.broadcastChanges();

				player.connection.send(new net.minecraft.network.protocol.game.ClientboundContainerSetSlotPacket(-1, -1, 0, cursorStack));
				player.connection.send(new net.minecraft.network.protocol.game.ClientboundContainerSetSlotPacket(
						player.containerMenu.containerId,
						player.containerMenu.incrementStateId(), 7, legItem
				));
			});
		});


		// Прием кликов от клиента и передача в миксин титана
		ServerPlayNetworking.registerGlobalReceiver(JawQteInputPayload.TYPE, (payload, context) -> {
			context.server().execute(() -> {
				ServerPlayer player = context.player();
				if (player == null) return;

				// 1. Если игрок бьет молот Челюстями
				if (player.getVehicle() instanceof IJawQteHandler jawTitan) {
					jawTitan.handleQtePress(payload.pressedKey());
				}

				// 2. Если игрок пытается вырваться из захвата шифтера
				ShifterGrabQteHandler.handleQtePress(player, payload.pressedKey());
			});
		});
		ServerPlayNetworking.registerGlobalReceiver(CarriageTeleportPayload.TYPE, (payload, context) -> {
			context.server().execute(() -> {
				var player = context.player();
				ICarriageData playerData = (ICarriageData) player;
				String cityId = payload.cityId();

				ResourceKey<net.minecraft.world.level.Level> paradisKey = ResourceKey.create(Registries.DIMENSION, ResourceLocation.fromNamespaceAndPath("dannys-aot", "paradis"));
				ServerLevel paradisLevel = player.getServer().getLevel(paradisKey);

				if (paradisLevel == null) return;

				// Если это лес
				if (cityId.equals("giant_forest") && playerData.maxon$isForestUnlocked()) {
					BlockPos forestPos = com.maxonaddon.util.ForestLocator.getCachedForestPos();

					if (forestPos != null) {
						player.teleportTo(paradisLevel, forestPos.getX(), forestPos.getY(), forestPos.getZ(), player.getYRot(), player.getXRot());
					} else {
						player.sendSystemMessage(Component.translatable("message.maxonaddon.carriage.forest_found_not").withStyle(ChatFormatting.RED));					}
					return;
				}
				// Если это открытый город
				if (playerData.maxon$getUnlockedCities().containsKey(cityId)) {
					// Берем координаты прямо из нашего словаря!
					BlockPos targetPos = playerData.maxon$getUnlockedCities().get(cityId);

					// Телепортируем на блок выше (targetPos.getY() + 1), чтобы не застрять в НПС
					player.teleportTo(paradisLevel, targetPos.getX(), targetPos.getY() + 1, targetPos.getZ(), player.getYRot(), player.getXRot());
				}
			});
		});

		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			ServerPlayer player = handler.player;
			IPlayerStats stats = (IPlayerStats) player;
			ServerPlayNetworking.send(player, new SyncFearStatsPayload(stats.getTitansKilled()));

			// Добавляем ungrabingMastery в список аргументов
			ServerPlayNetworking.send(player, new SyncSkillsPayload(new ArrayList<>(stats.getUnlockedSkills())));
		});

		Registry.register(BuiltInRegistries.BLOCK, ResourceLocation.fromNamespaceAndPath(MOD_ID, "gas_cisterna"), GAS_CISTERNA);
		Registry.register(BuiltInRegistries.ITEM, ResourceLocation.fromNamespaceAndPath(MOD_ID, "gas_cisterna"), GAS_CISTERNA_ITEM);
		Registry.register(BuiltInRegistries.ITEM, ResourceLocation.fromNamespaceAndPath(MOD_ID, "thunder_gun"), THUNDER_GUN_ITEM);
		// Регистрация кастомного партикла
		Registry.register(BuiltInRegistries.PARTICLE_TYPE, ResourceLocation.fromNamespaceAndPath(MOD_ID, "titan_steam"), TITAN_STEAM);

		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.FUNCTIONAL_BLOCKS).register(entries -> {
			entries.accept(GAS_CISTERNA_ITEM);
			entries.accept(THUNDER_GUN_ITEM);
		});

		ResourceKey<CreativeModeTab> daotBlocksTab = ResourceKey.create(
				Registries.CREATIVE_MODE_TAB,
				ResourceLocation.fromNamespaceAndPath("dannys-aot", "blocks")
		);


		ItemGroupEvents.modifyEntriesEvent(daotBlocksTab).register(entries -> {
			entries.accept(GAS_CISTERNA_ITEM);
			entries.accept(THUNDER_GUN_ITEM); // <--- ДОБАВЛЯЕМ СЮДА
		});

		ServerPlayNetworking.registerGlobalReceiver(ResetSkillsPayload.TYPE, (payload, context) -> {
			context.server().execute(() -> {
				ServerPlayer player = context.player();
				IPlayerStats stats = (IPlayerStats) player;

				int refundedSoldierSp = 0;
				int refundedBloodlinePoints = 0;
				int refundedTitanPoints = 0;

				// Автоматически проходим по всем навыкам из реестра ModSkill
				for (ModSkill skill : ModSkill.values()) {
					if (stats.hasSkill(skill.id)) {
						// Возвращаем очки в зависимости от категории навыка
						switch (skill.category) {
							case SOLDIER -> refundedSoldierSp += skill.cost;
							case BLOODLINE -> refundedBloodlinePoints += skill.cost;
							case TITAN -> refundedTitanPoints += skill.cost;
						}
					}
				}

				// Очищаем все изученные навыки разом
				stats.getUnlockedSkills().clear();

				// Сбрасываем старые булевы флаги (на всякий случай для обратной совместимости)
				stats.setOdmMastery(false);
				stats.setDashMastery(false);
				stats.setConnectorMastery(false);
				stats.setUngrabingMastery(false);
				stats.setBloodlineAwakening(false);
				stats.setShifterRegen(false);

				// Возвращаем очки игроку (солдатские SP = базовые за уровень + всё, что вернулось со скилов)
				stats.setSkillPoints((stats.getLevel() - 1) + refundedSoldierSp);
				stats.setBloodlinePoints(stats.getBloodlinePoints() + refundedBloodlinePoints);
				stats.setTitanPoints(stats.getTitanPoints() + refundedTitanPoints);

				player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
						net.minecraft.sounds.SoundEvents.BEACON_DEACTIVATE, net.minecraft.sounds.SoundSource.PLAYERS, 1.0F, 1.0F);
				player.displayClientMessage(Component.translatable("message.maxonaddon.skills.reset_success"), false);
				StatsCommand.sendPlayerStats(player);

				ServerPlayNetworking.send(player, new SyncSkillsPayload(new ArrayList<>()));
			});
		});

		ServerPlayNetworking.registerGlobalReceiver(RequestStatsPayload.TYPE, (payload, context) -> {
			context.server().execute(() -> {
				com.maxonaddon.command.StatsCommand.sendPlayerStats(context.player());
			});
		});

		// 1. Засчитываем убийство титана и ВЫДАЕМ ОПЫТ
		ServerEntityCombatEvents.AFTER_KILLED_OTHER_ENTITY.register((level, entity, killedEntity) -> {
			if (entity instanceof ServerPlayer player) {
				IPlayerStats stats = (IPlayerStats) player;

				String className = killedEntity.getClass().getSimpleName();
				if (className.contains("Titan") || className.contains("Fritz") || className.contains("ConnieFather")) {
					stats.addTitanKill();

					stats.setExp(stats.getExp() + 25);
					int requiredExp = 100 + (stats.getLevel() - 1) * 25;

					if (stats.getExp() >= requiredExp) {
						stats.setExp(stats.getExp() - requiredExp);
						stats.setLevel(stats.getLevel() + 1);
						stats.setSkillPoints(stats.getSkillPoints() + 1);

						player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
								net.minecraft.sounds.SoundEvents.PLAYER_LEVELUP, net.minecraft.sounds.SoundSource.PLAYERS, 1.0F, 1.0F);
					}

					ServerPlayNetworking.send(player, new SyncFearStatsPayload(stats.getTitansKilled()));
				}

				// === НАЧИСЛЕНИЕ ОЧКОВ ТИТАНА ===
				net.minecraft.world.entity.Entity vehicle = player.getRootVehicle();
				if (vehicle instanceof daot.AttackTitanEntity || vehicle instanceof daot.ArmoredTitanEntity ||
						vehicle instanceof daot.ColossalTitanEntity || vehicle instanceof daot.FemaleTitanEntity ||
						vehicle instanceof daot.BeastTitanEntity || vehicle instanceof daot.WarhammerTitanEntity) {

					stats.setTitanPoints(stats.getTitanPoints() + 1);
				}
			}
		});

		ServerPlayNetworking.registerGlobalReceiver(BuySkillPayload.TYPE, (payload, context) -> {
			context.server().execute(() -> {
				ServerPlayer player = context.player();
				IPlayerStats stats = (IPlayerStats) player;
				ModSkill skillToBuy = ModSkill.getById(payload.skillId());

				if (skillToBuy != null && !stats.hasSkill(skillToBuy.id)) {
					// Проверка стоимости в зависимости от категории
					boolean canAfford = switch (skillToBuy.category) {
						case SOLDIER -> stats.getSkillPoints() >= skillToBuy.cost;
						case TITAN -> stats.getTitanPoints() >= skillToBuy.cost;
						case BLOODLINE -> stats.getBloodlinePoints() >= skillToBuy.cost;
					};

					if (canAfford) {
						// Списываем очки
						switch (skillToBuy.category) {
							case SOLDIER -> stats.setSkillPoints(stats.getSkillPoints() - skillToBuy.cost);
							case TITAN -> stats.setTitanPoints(stats.getTitanPoints() - skillToBuy.cost);
							case BLOODLINE -> stats.setBloodlinePoints(stats.getBloodlinePoints() - skillToBuy.cost);
						}

						// Выдаем скилл
						stats.unlockSkill(skillToBuy.id);

						player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
								SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.8F, 2.0F);

						// Синхронизируем
						StatsCommand.sendPlayerStats(player);
						ServerPlayNetworking.send(player, new SyncSkillsPayload(
								new ArrayList<>(stats.getUnlockedSkills())
						));
					}
				}
			});
		});

		ServerPlayerEvents.COPY_FROM.register((oldPlayer, newPlayer, alive) -> {
			IPlayerStats oldStats = (IPlayerStats) oldPlayer;
			IPlayerStats newStats = (IPlayerStats) newPlayer;

			newStats.setTitansKilled(oldStats.getTitansKilled());
			newStats.setTicksPlayedTotal(oldStats.getTicksPlayedTotal());

			if (alive) {
				newStats.setTicksSinceDeath(oldStats.getTicksSinceDeath());
			} else {
				newStats.resetTicksSinceDeath();
			}
			for (com.maxonaddon.util.TraumaType type : com.maxonaddon.util.TraumaType.values()) {
				newStats.setTraumaTimer(type, oldStats.getTraumaTimer(type));
			}

			// === КОПИРУЕМ СИСТЕМУ ПРОКАЧКИ ===
			newStats.setLevel(oldStats.getLevel());
			newStats.setExp(oldStats.getExp());
			newStats.setSkillPoints(oldStats.getSkillPoints());
			newStats.setBloodlinePoints(oldStats.getBloodlinePoints());
			newStats.setTitanPoints(oldStats.getTitanPoints());

			// СОХРАНЯЕМ ВСЕ НАВЫКИ
			newStats.setOdmMastery(oldStats.hasOdmMastery());
			newStats.setUngrabingMastery(oldStats.hasUngrabingMastery());
			newStats.setDashMastery(oldStats.hasDashMastery());
			newStats.setConnectorMastery(oldStats.hasConnectorMastery());
			newStats.setBloodlineAwakening(oldStats.hasBloodlineAwakening());
			newStats.setShifterRegen(oldStats.hasShifterRegen());

			// ПАКЕТЫ ОТСЮДА УБРАНЫ (Они отправляются в AFTER_RESPAWN)
		});

		// === НОВОЕ СОБЫТИЕ: СИНХРОНИЗАЦИЯ ПОСЛЕ ВОЗРОЖДЕНИЯ ===
		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
			IPlayerStats newStats = (IPlayerStats) newPlayer;
			ServerPlayNetworking.send(newPlayer, new SyncFearStatsPayload(newStats.getTitansKilled()));
			ServerPlayNetworking.send(newPlayer, new SyncSkillsPayload(new ArrayList<>(newStats.getUnlockedSkills())));
			com.maxonaddon.util.TraumaManager.reapplyTraumas(newPlayer);
		});

		net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((player, origin, destination) -> {
			IPlayerStats stats = (IPlayerStats) player;
			ServerPlayNetworking.send(player, new SyncFearStatsPayload(stats.getTitansKilled()));
			ServerPlayNetworking.send(player, new SyncSkillsPayload(new ArrayList<>(stats.getUnlockedSkills())));
		});

		// === 2. ИНИЦИАЛИЗАЦИЯ МЕХАНИК ===
		HostileQteHandler.register();
		ShifterGrabQteHandler.register();
		CarriageSpawner.register();
		RoyalTitanInteractHandler.register();
		BerserkBossHandler.register();
		BerserkConfig.register();
		RedTitanCommand.register();
		CarriageInteractHandler.register();
		ApgConfig.register();
		ScoutSpawner.init();
		MaxonConfig.registerGameRules();
		MaxonConfig.load();
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			Map<UUID, Float> charges = com.maxonaddon.mixin.AwakenedPowerTrackerAccessor.getCharges();

			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				if (charges.containsKey(player.getUUID()) && player.getTags().contains("dannys-aot:awakened_power")) {
					IPlayerStats stats = (IPlayerStats) player;

					// Базовый расход в моде = 0.15 за тик.
					// Если навыка "Контроль 2" НЕТ, мы вычитаем дополнительную стамину:
					float extraDrain = 0.0f;

					if (!stats.hasSkill("ackerman_control_2")) {
						if (stats.hasSkill("ackerman_control_1")) {
							extraDrain = 0.06f; // +20% стамины (тратится чуть быстрее нормы, итого ~70% от максимума)
						} else {
							extraDrain = 0.15f; // -50% стамины (тратится в 2 раза быстрее: 0.15 мод + 0.15 наше)
						}
					}

					if (extraDrain > 0.0f) {
						float current = charges.get(player.getUUID());
						charges.put(player.getUUID(), Math.max(0.0f, current - extraDrain));
					}
				}
			}
		});

		// === ПРОВЕРКА ЭФФЕКТА РЕГЕНЕРАЦИИ ДЛЯ СБРОСА ТРАВМ ДО 30 СЕК ===
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				if (player.tickCount % 20 == 0) {
					if (player.hasEffect(net.minecraft.world.effect.MobEffects.REGENERATION)) {
						IPlayerStats stats = (IPlayerStats) player;
						int targetTicks = 600; // 30 секунд
						boolean healedAny = false;

						for (com.maxonaddon.util.TraumaType type : com.maxonaddon.util.TraumaType.values()) {
							if (stats.getTraumaTimer(type) > targetTicks) {
								stats.setTraumaTimer(type, targetTicks);
								TraumaManager.syncTrauma(player, type);
								healedAny = true;
							}
						}

						if (healedAny) {
							player.displayClientMessage(
									Component.translatable("message.maxonaddon.trauma.healed_by_apple").withStyle(ChatFormatting.GOLD),
									true
							);
						}
					}
				}
			}
		});

		// === ГЛОБАЛЬНАЯ ПРОВЕРКА НАВЫКА УПМ (ТИХИЙ ДЖЕМ) ===
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				((IPlayerStats) player).incrementTicksPlayed();
				com.maxonaddon.util.TraumaManager.tickTraumas(player);

				IPlayerStats stats = (IPlayerStats) player;

				// === ЖЕСТКАЯ БЛОКИРОВКА НОГ (БЕГ) ПРИ ТРАВМЕ ===
				if (stats.hasTrauma(com.maxonaddon.util.TraumaType.LEGS)) {
					if (player.isSprinting()) {
						player.setSprinting(false);
					}
				}

				// === ЖЕСТКАЯ БЛОКИРОВКА ЛЕВОЙ РУКИ ПРИ ТРАВМЕ ===
				if (stats.hasTrauma(com.maxonaddon.util.TraumaType.ARMS)) {
					ItemStack offhand = player.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.OFFHAND);
					if (!offhand.isEmpty()) {
						player.drop(offhand.copy(), true, false);
						player.setItemInHand(net.minecraft.world.InteractionHand.OFF_HAND, ItemStack.EMPTY);
					}
				}

				// === ПРОВЕРКА НАВЫКА И ПРОЧНОСТИ УПМ ===
				ItemStack legs = player.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.LEGS);
				if (legs.getItem() instanceof daot.ODMGearItem) {
					// 1. Сначала проверяем, есть ли вообще навык на УПМ
					if (!stats.hasOdmMastery()) {
						// Если навыка нет — перманентный клин (отцепляет крюки)
						if (player.tickCount % 20 == 0) {
							ServerPlayNetworking.send(player, new SilentJamPayload(2000));

							// Пишем над панелью быстрого доступа (ActionBar, true), что нужен навык
							player.displayClientMessage(
									net.minecraft.network.chat.Component.translatable("gui.maxonaddon.skills.odm_required"),
									true
							);
						}
					} else {
						// 2. Если навык есть — проверяем износ, сырость и прочность (твоя утилита)
						com.maxonaddon.util.ODMDamageManager.serverTick(player);
					}
				}
			}
		});

		ServerPlayNetworking.registerGlobalReceiver(DashPayload.TYPE, (payload, context) -> {
			context.server().execute(() -> {
				ServerPlayer player = context.player();
				IPlayerStats stats = (IPlayerStats) player;
				ItemStack legItem = player.getItemBySlot(EquipmentSlot.LEGS);

				boolean isCrackedRuleEnabled = player.level().getGameRules().getBoolean(MaxonConfig.DO_ODM_CRACKED);
				if (isCrackedRuleEnabled && com.maxonaddon.util.ODMDamageManager.getDurability(legItem) <= 0) {
					player.displayClientMessage(Component.translatable("message.maxonaddon.odm.broken"), true);
					return;
				}

				if (!DannysAot.isODMGear(legItem.getItem())) return;
				if (player.isPassenger() || !hasOdmTriggers(player)) return;

				if (!stats.hasDashMastery()) {
					player.displayClientMessage(Component.translatable("gui.maxonaddon.skills.dash_required"), true);
					return;
				}

				int currentGas = DannysAot.getGasFromGear(legItem);
				if (currentGas < 20) {
					player.displayClientMessage(Component.translatable("message.maxonaddon.dash.not_enough_gas"), true);
					return;
				}

				DannysAot.consumeGasFromGear(legItem, 20, player);
				Vec3 look = player.getLookAngle();
				Vec3 dashVec = new Vec3(look.x * 2, look.y * 2 + 0.3, look.z * 2);

				player.setDeltaMovement(dashVec);
				player.hurtMarked = true;
				player.fallDistance = 0.0F;
				player.addTag("odm_dashing");

				ServerLevel level = (ServerLevel) player.level();
				level.playSound(null, player.getX(), player.getY(), player.getZ(),
						SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.6F, 1.5F);
				level.playSound(null, player.getX(), player.getY(), player.getZ(),
						SoundEvents.ENDER_DRAGON_FLAP, SoundSource.PLAYERS, 0.4F, 2.0F);

				level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE,
						player.getX(), player.getY() + 1.0, player.getZ(), 20, 0.5, 0.5, 0.5, 0.1);
				level.sendParticles(ParticleTypes.CLOUD,
						player.getX(), player.getY() + 1.0, player.getZ(), 15, 0.3, 0.3, 0.3, 0.2);

				detachHooksFromPlayer(player);
			});
		});

		UseItemCallback.EVENT.register((player, world, hand) -> {
			ItemStack stack = player.getItemInHand(hand);

			if (world.isClientSide()) {
				return InteractionResultHolder.pass(stack);
			}

			String itemId = net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();

			if (itemId.contains("syringe") || itemId.contains("spinal_fluid")) {
				player.removeTag("has_shifted_before");
				player.removeTag("berserk_boss");
			}

			return InteractionResultHolder.pass(stack);
		});

		ServerPlayNetworking.registerGlobalReceiver(BackDashPayload.TYPE, (payload, context) -> {
			context.server().execute(() -> {
				ServerPlayer player = context.player();
				IPlayerStats stats = (IPlayerStats) player;
				ItemStack legItem = player.getItemBySlot(EquipmentSlot.LEGS);

				if (!DannysAot.isODMGear(legItem.getItem())) return;
				if (player.isPassenger() || !hasOdmTriggers(player)) return;

				boolean isCrackedRuleEnabled = player.level().getGameRules().getBoolean(MaxonConfig.DO_ODM_CRACKED);
				if (isCrackedRuleEnabled && com.maxonaddon.util.ODMDamageManager.getDurability(legItem) <= 0) {
					player.displayClientMessage(Component.translatable("message.maxonaddon.odm.broken"), true);
					return;
				}

				if (!stats.hasDashMastery()) {
					player.displayClientMessage(Component.translatable("gui.maxonaddon.skills.dash_required"), true);
					return;
				}

				int currentGas = DannysAot.getGasFromGear(legItem);
				if (currentGas < 20) {
					player.displayClientMessage(Component.translatable("message.maxonaddon.dash.not_enough_gas"), true);
					return;
				}

				DannysAot.consumeGasFromGear(legItem, 20, player);
				Vec3 look = player.getLookAngle();
				Vec3 dashVec = new Vec3(-look.x * 2, 0.4, -look.z * 2);

				player.setDeltaMovement(dashVec);
				player.hurtMarked = true;
				player.fallDistance = 0.0F;
				player.addTag("odm_dashing");

				ServerLevel level = (ServerLevel) player.level();
				level.playSound(null, player.getX(), player.getY(), player.getZ(),
						SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.6F, 1.5F);
				level.playSound(null, player.getX(), player.getY(), player.getZ(),
						SoundEvents.ENDER_DRAGON_FLAP, SoundSource.PLAYERS, 0.4F, 2.0F);

				level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE,
						player.getX(), player.getY() + 1.0, player.getZ(), 20, 0.5, 0.5, 0.5, 0.1);
				level.sendParticles(ParticleTypes.CLOUD,
						player.getX(), player.getY() + 1.0, player.getZ(), 15, 0.3, 0.3, 0.3, 0.2);

				detachHooksFromPlayer(player);
			});
		});

		ServerPlayNetworking.registerGlobalReceiver(RequestJamPayload.TYPE, (payload, context) -> {
			context.server().execute(() -> {
				ServerPlayer player = context.player();
				ServerPlayNetworking.send(player, new ODMJamPayload(1000));
			});
		});

		ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
			if (entity instanceof ServerPlayer player) {
				net.minecraft.world.entity.Entity attacker = source.getEntity();

				if (attacker instanceof ShifterTitan || attacker instanceof OgreTitanEntity || attacker instanceof net.minecraft.world.entity.monster.Monster) {

					// Наносим урон прочности УПМ при ударе титана
					ItemStack legs = player.getItemBySlot(EquipmentSlot.LEGS);
					if (legs.getItem() instanceof daot.ODMGearItem) {
						com.maxonaddon.util.ODMDamageManager.damageOdm(player, legs, 15);
					}

					// Берем порог урона и шанс из конфига

					MaxonConfig config = MaxonConfig.get();
					double traumaChance = config.traumaChanceOnDamage;
					IPlayerStats stats = (IPlayerStats) player;

// Наслаиваем Железные кости: снижаем базовую вероятность травмы
					if (stats.hasSkill("iron_bones_1")) {
						traumaChance -= 0.02; // -2% вероятности
					}
					if (stats.hasSkill("iron_bones_2")) {
						traumaChance -= 0.02; // еще -2% вероятности (в сумме -4%)
					}

// Защита от ухода в отрицательный процент
					if (traumaChance < 0) traumaChance = 0.0;

					if (amount >= config.traumaDamageThreshold && player.getRandom().nextDouble() < traumaChance) {
						TraumaManager.applyRandomTrauma(player);
					}
				}
			}
			return true;
		});

		ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
			if (entity instanceof ServerPlayer player) {

				if (player.getTags().contains("titan_blocking_damage")) {
					return true;
				}

				if (player.getTags().contains("odm_dashing") && source.is(DamageTypes.FALL)) {
					player.removeTag("odm_dashing");
					return false;
				}

				if (source.is(DamageTypes.FALL) && RoyalTitanInteractHandler.fallImmunity.containsKey(player.getUUID())) {
					return false;
				}

				net.minecraft.world.entity.Entity attacker = source.getEntity();



				if (attacker instanceof ServerPlayer attackingPlayer) {
					ItemStack attackerMain = attackingPlayer.getMainHandItem();
					ItemStack attackerOff = attackingPlayer.getOffhandItem();

					if (attackerMain.getItem() instanceof daot.BladeItem || attackerOff.getItem() instanceof daot.BladeItem) {
						if (daot.BladeBlockTracker.isBlocking(player)) {
							ItemStack defenderMain = player.getMainHandItem();
							ItemStack defenderOff = player.getOffhandItem();

							if (defenderMain.getItem() instanceof daot.BladeItem && defenderOff.getItem() instanceof daot.BladeItem) {
								if (daot.BladeItem.getBladeState(defenderMain) != daot.BladeItem.BladeState.EMPTY &&
										daot.BladeItem.getBladeState(defenderOff) != daot.BladeItem.BladeState.EMPTY) {

									Integer blockStartTick = blockStartTicks.get(player.getUUID());
									int currentTick = player.serverLevel().getServer().getTickCount();

									if (blockStartTick != null && (currentTick - blockStartTick) <= 20) {
										net.minecraft.world.item.Item bladeItem = attackerMain.getItem() instanceof daot.BladeItem ? attackerMain.getItem() : attackerOff.getItem();
										attackingPlayer.getCooldowns().addCooldown(bladeItem, 40);

										if (player.level() instanceof ServerLevel serverLevel) {
											serverLevel.playSound(null, player.getX(), player.getY(), player.getZ(),
													net.minecraft.sounds.SoundEvents.SHIELD_BLOCK, SoundSource.PLAYERS, 1.0F, 1.2F);
											serverLevel.playSound(null, player.getX(), player.getY(), player.getZ(),
													net.minecraft.sounds.SoundEvents.ANVIL_PLACE, SoundSource.PLAYERS, 0.4F, 2.0F);

											serverLevel.sendParticles(ParticleTypes.CRIT,
													player.getX(), player.getY() + 1.0, player.getZ(),
													15, 0.5, 0.5, 0.5, 0.2);
										}

										Vec3 pushBack = attackingPlayer.position().subtract(player.position()).normalize().scale(0.5).add(0.0, 0.2, 0.0);
										attackingPlayer.setDeltaMovement(pushBack);
										attackingPlayer.hurtMarked = true;

										daot.BladeItem.damageBladeByAmount(defenderMain, 5, player);
										daot.BladeItem.damageBladeByAmount(defenderOff, 5, player);

										return false;
									}
								}
							}
						}
					}
				}

				if (attacker instanceof ShifterTitan || attacker instanceof OgreTitanEntity) {
					if (BladeBlockTracker.isBlocking(player)) {
						ItemStack mainHand = player.getMainHandItem();
						ItemStack offHand = player.getOffhandItem();

						if (mainHand.getItem() instanceof BladeItem && offHand.getItem() instanceof BladeItem) {
							if (BladeItem.getBladeState(mainHand) != BladeItem.BladeState.EMPTY &&
									BladeItem.getBladeState(offHand) != BladeItem.BladeState.EMPTY) {

								BladeItem.damageBladeByAmount(mainHand, 40, player);
								BladeItem.damageBladeByAmount(offHand, 40, player);
								BladeBlockTracker.breakBlock(player);

								Vec3 knockbackDir = player.position().subtract(attacker.position()).normalize();
								player.setDeltaMovement(knockbackDir.scale(4.5).add(0.0, 0.9, 0.0));
								player.hurtMarked = true;
								player.hasImpulse = true;

								if (player.level() instanceof ServerLevel serverLevel) {
									serverLevel.playSound(null, player.getX(), player.getY(), player.getZ(),
											net.minecraft.sounds.SoundEvents.GRAVEL_BREAK, SoundSource.PLAYERS, 2.0F, 0.8F);

									serverLevel.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.GRAVEL.defaultBlockState()),
											player.getX(), player.getY() + 1.0, player.getZ(),
											60, 0.5, 0.5, 0.5, 0.15);
								}

								player.addTag("titan_blocking_damage");
								player.hurt(source, amount * 0.5F);
								player.removeTag("titan_blocking_damage");

								return false;
							}
						}
					}
				}
			}

			return true;
		});
	}

	private void registerCommands() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
			com.maxonaddon.command.TraumaCommand.register(dispatcher);
			SpawnCarriageCommand.register(dispatcher);
			dispatcher.register(Commands.literal("spawnboulder")
					.requires(source -> source.hasPermission(2))
					.executes(context -> {
						ServerPlayer player = context.getSource().getPlayer();
						if (player != null) {
							TitanBoulderEntity boulder = new TitanBoulderEntity(ModEntities.TITAN_BOULDER, player.level());
							boulder.setPos(player.getX(), player.getY(), player.getZ());
							player.level().addFreshEntity(boulder);
							context.getSource().sendSuccess(() -> Component.translatable("command.maxonaddon.spawnboulder.success"), false);
						}
						return 1;
					}));
		});
	}


	private static boolean hasOdmTriggers(ServerPlayer player) {
		net.minecraft.world.item.Item mainItem = player.getMainHandItem().getItem();
		net.minecraft.world.item.Item offItem = player.getOffhandItem().getItem();

		// Проверяем мечи и обычные пушки через instanceof
		boolean mainIsBladeOrGun = mainItem instanceof daot.BladeItem || mainItem instanceof daot.APGGunItem;
		boolean offIsBladeOrGun = offItem instanceof daot.BladeItem || offItem instanceof daot.APGGunItem;

		// Проверяем THUNDER_GUN_ITEM через точноеравнение (==)
		boolean mainIsThunder = mainItem == MaxonDaotAddon.THUNDER_GUN_ITEM;
		boolean offIsThunder = offItem == MaxonDaotAddon.THUNDER_GUN_ITEM;

		return mainIsBladeOrGun || offIsBladeOrGun || mainIsThunder || offIsThunder;
	}

	private static void detachHooksFromPlayer(ServerPlayer dashingPlayer) {
		ServerLevel level = dashingPlayer.serverLevel();

		for (ServerPlayer attacker : level.players()) {
			if (attacker == dashingPlayer) continue;

			if (ServerHookTracker.hasActiveHook(attacker.getUUID())) {
				ServerPlayNetworking.send(attacker, new ForceDetachPayload(dashingPlayer.getId()));
			}
		}
	}

	private static void tryLoadThunderGun(ServerPlayer player, InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);
		if (stack.getItem() instanceof com.maxonaddon.item.ThunderGunItem) {
			int loaded = com.maxonaddon.item.ThunderGunItem.getLoadedSpears(stack);

			// 1. Если пушка полностью заряжена (2 копья) -> ВЫТАСКИВАЕМ ВСЁ
			if (loaded == com.maxonaddon.item.ThunderGunItem.MAX_LOADED_SPEARS) {
				unloadAllSpears(player, stack, loaded);
				return;
			}

			// 2. Если пушка не полная -> Ищем копье в инвентаре для дозарядки
			int spearSlot = -1;
			for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
				if (player.getInventory().getItem(i).getItem() instanceof daot.ThunderSpearItem) {
					spearSlot = i;
					break;
				}
			}

			if (spearSlot != -1 || player.isCreative()) {
				// Если копье есть -> Заряжаем 1 штуку
				if (!player.isCreative()) {
					player.getInventory().getItem(spearSlot).shrink(1);
				}
				com.maxonaddon.item.ThunderGunItem.setLoadedSpears(stack, loaded + 1);
				player.level().playSound(null, player.getX(), player.getY(), player.getZ(), net.minecraft.sounds.SoundEvents.CROSSBOW_LOADING_END, net.minecraft.sounds.SoundSource.PLAYERS, 1.0F, 1.0F);

				// Анимация зарядки: 0 -> load, 1 -> load2
				String animName = (loaded == 0) ? "load" : "load2";
				if (stack.getItem() instanceof software.bernie.geckolib.animatable.GeoItem geoItem) {
					geoItem.triggerAnim(player, software.bernie.geckolib.animatable.GeoItem.getOrAssignId(stack, player.serverLevel()), "controller", animName);
				}
			} else if (loaded > 0) {
				// Если копий в инвентаре больше нет, но 1 заряд уже в пушке -> ВЫТАСКИВАЕМ ЕГО
				unloadAllSpears(player, stack, loaded);
			}
		}
	}

	private static void unloadAllSpears(ServerPlayer player, ItemStack stack, int loaded) {
		// Создаем стак с количеством копий, равным текущим зарядам
		ItemStack spearsToGive = new ItemStack(daot.DannysAot.THUNDER_SPEAR, loaded);

		// Пытаемся положить в инвентарь. Если места нет - бросаем на землю
		if (!player.getInventory().add(spearsToGive)) {
			player.drop(spearsToGive, false);
		}

		// Обнуляем заряды пушки
		com.maxonaddon.item.ThunderGunItem.setLoadedSpears(stack, 0);
		player.level().playSound(null, player.getX(), player.getY(), player.getZ(), net.minecraft.sounds.SoundEvents.ARMOR_EQUIP_IRON.value(), net.minecraft.sounds.SoundSource.PLAYERS, 1.0F, 1.0F);

		// Анимация разрядки: 2 -> unload2, 1 -> unload
		String animName = (loaded == 2) ? "unload2" : "unload";
		if (stack.getItem() instanceof software.bernie.geckolib.animatable.GeoItem geoItem) {
			geoItem.triggerAnim(player, software.bernie.geckolib.animatable.GeoItem.getOrAssignId(stack, player.serverLevel()), "controller", animName);
		}
	}

	private static void performMaxonReload(ServerPlayer player) {
		com.maxonaddon.util.IPlayerStats stats = (com.maxonaddon.util.IPlayerStats) player;
		ItemStack legItem = player.getItemBySlot(EquipmentSlot.LEGS);
		boolean isOdm = legItem.getItem() instanceof daot.ODMGearItem;
		boolean isApg = legItem.getItem() instanceof daot.ODMAPGItem;
		if (!isOdm && !isApg) return;

		net.minecraft.world.item.component.ItemContainerContents contents = legItem.getOrDefault(net.minecraft.core.component.DataComponents.CONTAINER, net.minecraft.world.item.component.ItemContainerContents.EMPTY);
		net.minecraft.core.NonNullList<ItemStack> items = net.minecraft.core.NonNullList.withSize(2, ItemStack.EMPTY);
		contents.copyInto(items);

		boolean inventoryChanged = false;

		boolean hasCartridges = items.get(0).getItem() instanceof daot.APGCartridgeItem || items.get(1).getItem() instanceof daot.APGCartridgeItem;
		boolean hasBlades = items.get(0).getItem() instanceof daot.BladeComponentItem || items.get(1).getItem() instanceof daot.BladeComponentItem;

		boolean canUseBlades = (isOdm && !hasCartridges) || (isApg && stats.hasConnectorMastery() && !hasCartridges);
		boolean canUseGuns = (isApg && !hasBlades) || (isOdm && stats.hasConnectorMastery() && !hasBlades);

		InteractionHand[] hands = {InteractionHand.MAIN_HAND, InteractionHand.OFF_HAND};
		for (InteractionHand hand : hands) {
			ItemStack handStack = player.getItemInHand(hand);

			// --- ЛОГИКА МЕЧЕЙ ---
			if (canUseBlades && handStack.getItem() instanceof daot.BladeItem) {
				if (daot.BladeItem.getBladeState(handStack) == daot.BladeItem.BladeState.EMPTY) {
					if (player.isCreative()) {
						daot.BladeItem.reloadBlade(handStack);
						player.level().playSound(null, player.getX(), player.getY(), player.getZ(), net.minecraft.sounds.SoundEvents.IRON_DOOR_OPEN, net.minecraft.sounds.SoundSource.PLAYERS, 1.0F, 1.5F);
					} else {
						boolean hasLeft = items.get(0).getItem() instanceof daot.BladeComponentItem && items.get(0).getCount() > 0;
						boolean hasRight = items.get(1).getItem() instanceof daot.BladeComponentItem && items.get(1).getCount() > 0;

						int takeIndex = -1;
						if (hasLeft && hasRight) takeIndex = (items.get(0).getCount() >= items.get(1).getCount()) ? 0 : 1;
						else if (hasLeft) takeIndex = 0;
						else if (hasRight) takeIndex = 1;

						if (takeIndex != -1) {
							items.get(takeIndex).shrink(1);
							inventoryChanged = true;
							daot.BladeItem.reloadBlade(handStack);
							player.level().playSound(null, player.getX(), player.getY(), player.getZ(), net.minecraft.sounds.SoundEvents.IRON_DOOR_OPEN, net.minecraft.sounds.SoundSource.PLAYERS, 1.0F, 1.5F);
						}
					}
				} else {
					if (!player.isCreative() && daot.BladeItem.getBladeDamage(handStack) == 0) {
						boolean canPutLeft = !hasCartridges && (items.get(0).isEmpty() || (items.get(0).getItem() instanceof daot.BladeComponentItem && items.get(0).getCount() < 2));
						boolean canPutRight = !hasCartridges && (items.get(1).isEmpty() || (items.get(1).getItem() instanceof daot.BladeComponentItem && items.get(1).getCount() < 2));

						int putIndex = -1;
						if (canPutLeft && canPutRight) putIndex = (items.get(0).getCount() <= items.get(1).getCount()) ? 0 : 1;
						else if (canPutLeft) putIndex = 0;
						else if (canPutRight) putIndex = 1;

						if (putIndex != -1) {
							ItemStack slotStack = items.get(putIndex);
							if (slotStack.isEmpty()) items.set(putIndex, new ItemStack(daot.DannysAot.BLADE_COMPONENT, 1));
							else slotStack.grow(1);
							inventoryChanged = true;
						} else {
							ItemStack toReturn = new ItemStack(daot.DannysAot.BLADE_COMPONENT, 1);
							if (!player.getInventory().add(toReturn)) player.drop(toReturn, false);
						}
					}
					daot.BladeItem.ejectBlade(handStack, player, hand);
				}
			}

			// --- ЛОГИКА ОГНЕСТРЕЛА ---
			if (canUseGuns && handStack.getItem() instanceof daot.APGGunItem apgGun) {
				if (!daot.APGGunItem.isLoaded(handStack)) {
					if (player.isCreative()) {
						daot.APGGunItem.setLoaded(handStack, true);
						daot.APGGunItem.triggerAnim(player, handStack, "load");
						player.level().playSound(null, player.getX(), player.getY(), player.getZ(), net.minecraft.sounds.SoundEvents.CROSSBOW_LOADING_END, net.minecraft.sounds.SoundSource.PLAYERS, 1.0F, 1.5F);
					} else {
						boolean hasLeft = items.get(0).getItem() instanceof daot.APGCartridgeItem && items.get(0).getCount() > 0;
						boolean hasRight = items.get(1).getItem() instanceof daot.APGCartridgeItem && items.get(1).getCount() > 0;

						int takeIndex = -1;
						if (hasLeft && hasRight) takeIndex = (items.get(0).getCount() >= items.get(1).getCount()) ? 0 : 1;
						else if (hasLeft) takeIndex = 0;
						else if (hasRight) takeIndex = 1;

						if (takeIndex != -1) {
							items.get(takeIndex).shrink(1);
							inventoryChanged = true;
							daot.APGGunItem.setLoaded(handStack, true);
							daot.APGGunItem.triggerAnim(player, handStack, "load");
							player.level().playSound(null, player.getX(), player.getY(), player.getZ(), net.minecraft.sounds.SoundEvents.CROSSBOW_LOADING_END, net.minecraft.sounds.SoundSource.PLAYERS, 1.0F, 1.5F);
						}
					}
				} else {
					if (!player.isCreative()) {
						boolean canPutLeft = !hasBlades && (items.get(0).isEmpty() || (items.get(0).getItem() instanceof daot.APGCartridgeItem && items.get(0).getCount() < 3));
						boolean canPutRight = !hasBlades && (items.get(1).isEmpty() || (items.get(1).getItem() instanceof daot.APGCartridgeItem && items.get(1).getCount() < 3));

						int putIndex = -1;
						if (canPutLeft && canPutRight) putIndex = (items.get(0).getCount() <= items.get(1).getCount()) ? 0 : 1;
						else if (canPutLeft) putIndex = 0;
						else if (canPutRight) putIndex = 1;

						if (putIndex != -1) {
							ItemStack slotStack = items.get(putIndex);
							if (slotStack.isEmpty()) items.set(putIndex, new ItemStack(daot.DannysAot.APG_CARTRIDGE, 1));
							else slotStack.grow(1);
							inventoryChanged = true;
						} else {
							ItemStack toReturn = new ItemStack(daot.DannysAot.APG_CARTRIDGE, 1);
							if (!player.getInventory().add(toReturn)) player.drop(toReturn, false);
						}
					}
					daot.APGGunItem.setLoaded(handStack, false);
					daot.APGGunItem.triggerAnim(player, handStack, "unload");
					player.level().playSound(null, player.getX(), player.getY(), player.getZ(), net.minecraft.sounds.SoundEvents.ARMOR_EQUIP_IRON.value(), net.minecraft.sounds.SoundSource.PLAYERS, 1.0F, 1.5F);
				}
			}
		}

		if (inventoryChanged) {
			legItem.set(net.minecraft.core.component.DataComponents.CONTAINER, net.minecraft.world.item.component.ItemContainerContents.fromItems(java.util.List.copyOf(items)));
		}
	}
	private static void tryUnloadThunderGun(ServerPlayer player, InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);
		if (stack.getItem() instanceof com.maxonaddon.item.ThunderGunItem) {
			int loaded = com.maxonaddon.item.ThunderGunItem.getLoadedSpears(stack);
			if (loaded > 0) {
				// Возвращаем копье в инвентарь (или выкидываем на землю, если места нет)
				ItemStack spearToGive = new ItemStack(daot.DannysAot.THUNDER_SPEAR, 1);
				if (!player.getInventory().add(spearToGive)) {
					player.drop(spearToGive, false);
				}

				com.maxonaddon.item.ThunderGunItem.setLoadedSpears(stack, loaded - 1);
				player.level().playSound(null, player.getX(), player.getY(), player.getZ(), net.minecraft.sounds.SoundEvents.ARMOR_EQUIP_IRON.value(), net.minecraft.sounds.SoundSource.PLAYERS, 1.0F, 1.0F);

				// Анимация разрядки: 2 -> unload2, 1 -> unload
				String animName = (loaded == 2) ? "unload2" : "unload";
				if (stack.getItem() instanceof software.bernie.geckolib.animatable.GeoItem geoItem) {
					geoItem.triggerAnim(player, software.bernie.geckolib.animatable.GeoItem.getOrAssignId(stack, player.serverLevel()), "controller", animName);
				}
			}
		}
	}
	public static ResourceLocation id(String path) {
		return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
	}
}